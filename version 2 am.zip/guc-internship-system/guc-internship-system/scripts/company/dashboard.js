document.addEventListener('DOMContentLoaded', function() {
    // Mobile sidebar toggle
    const mobileMenuToggle = document.createElement('button');
    mobileMenuToggle.className = 'mobile-menu-toggle btn primary-btn';
    mobileMenuToggle.innerHTML = '<i class="fas fa-bars"></i> Menu';
    
    const contentHeader = document.querySelector('.content-header');
    if (contentHeader && window.innerWidth < 768) {
        contentHeader.insertBefore(mobileMenuToggle, contentHeader.firstChild);
        
        const sidebar = document.querySelector('.sidebar');
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // Load company dashboard data
    loadDashboardData();
    
    // Responsive adjustments
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 768 && document.querySelector('.mobile-menu-toggle')) {
            document.querySelector('.mobile-menu-toggle').remove();
            document.querySelector('.sidebar').classList.remove('active');
        }
    });
});

function loadDashboardData() {
    // In a real app, this would be an API call
    console.log('Loading company dashboard data...');
    
    // Simulate loading data
    setTimeout(() => {
        // Process and display data
        console.log('Company dashboard data loaded');
        
        // Update application status badges
        updateApplicationStatuses();
    }, 800);
}

function updateApplicationStatuses() {
    const statusBadges = document.querySelectorAll('.status-badge');
    
    statusBadges.forEach(badge => {
        if (badge.classList.contains('pending')) {
            badge.innerHTML = '<i class="fas fa-clock"></i> Pending Review';
        } else if (badge.classList.contains('accepted')) {
            badge.innerHTML = '<i class="fas fa-check-circle"></i> Accepted';
        } else if (badge.classList.contains('rejected')) {
            badge.innerHTML = '<i class="fas fa-times-circle"></i> Rejected';
        }
    });
}