// Student Report Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Tab functionality
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    if (tabButtons.length > 0 && tabContents.length > 0) {
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons and contents
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Add active class to clicked button
                this.classList.add('active');
                
                // Show corresponding content
                const tabId = this.getAttribute('data-tab');
                document.getElementById(tabId).classList.add('active');
            });
        });
    }
    
    // Navigation between tabs
    const nextToIntroBtn = document.getElementById('nextToIntroBtn');
    const backToBasicBtn = document.getElementById('backToBasicBtn');
    const nextToBodyBtn = document.getElementById('nextToBodyBtn');
    const backToIntroBtn = document.getElementById('backToIntroBtn');
    const nextToCoursesBtn = document.getElementById('nextToCoursesBtn');
    const backToBodyBtn = document.getElementById('backToBodyBtn');
    const nextToPreviewBtn = document.getElementById('nextToPreviewBtn');
    const backToCoursesBtn = document.getElementById('backToCoursesBtn');
    
    if (nextToIntroBtn) {
        nextToIntroBtn.addEventListener('click', function() {
            document.querySelector('[data-tab="introduction"]').click();
        });
    }
    
    if (backToBasicBtn) {
        backToBasicBtn.addEventListener('click', function() {
            document.querySelector('[data-tab="basic"]').click();
        });
    }
    
    if (nextToBodyBtn) {
        nextToBodyBtn.addEventListener('click', function() {
            document.querySelector('[data-tab="body"]').click();
        });
    }
    
    if (backToIntroBtn) {
        backToIntroBtn.addEventListener('click', function() {
            document.querySelector('[data-tab="introduction"]').click();
        });
    }
    
    if (nextToCoursesBtn) {
        nextToCoursesBtn.addEventListener('click', function() {
            document.querySelector('[data-tab="courses"]').click();
        });
    }
    
    if (backToBodyBtn) {
        backToBodyBtn.addEventListener('click', function() {
            document.querySelector('[data-tab="body"]').click();
        });
    }
    
    if (nextToPreviewBtn) {
        nextToPreviewBtn.addEventListener('click', function() {
            document.querySelector('[data-tab="preview"]').click();
            updatePreview();
        });
    }
    
    if (backToCoursesBtn) {
        backToCoursesBtn.addEventListener('click', function() {
            document.querySelector('[data-tab="courses"]').click();
        });
    }
    
    // Save functionality
    const saveBasicBtn = document.getElementById('saveBasicBtn');
    const saveIntroBtn = document.getElementById('saveIntroBtn');
    const saveBodyBtn = document.getElementById('saveBodyBtn');
    const saveCoursesBtn = document.getElementById('saveCoursesBtn');
    
    if (saveBasicBtn) {
        saveBasicBtn.addEventListener('click', function() {
            alert('Basic information saved successfully!');
        });
    }
    
    if (saveIntroBtn) {
        saveIntroBtn.addEventListener('click', function() {
            alert('Introduction saved successfully!');
        });
    }
    
    if (saveBodyBtn) {
        saveBodyBtn.addEventListener('click', function() {
            alert('Report body saved successfully!');
        });
    }
    
    if (saveCoursesBtn) {
        saveCoursesBtn.addEventListener('click', function() {
            alert('Course information saved successfully!');
        });
    }
    
    // Update preview
    function updatePreview() {
        // Update title
        const reportTitle = document.getElementById('reportTitle');
        const previewTitle = document.getElementById('previewTitle');
        if (reportTitle && previewTitle) {
            previewTitle.textContent = reportTitle.value;
        }
        
        // Update company overview
        const companyOverview = document.getElementById('companyOverview');
        const previewCompanyOverview = document.getElementById('previewCompanyOverview');
        if (companyOverview && previewCompanyOverview) {
            previewCompanyOverview.textContent = companyOverview.value;
        }
        
        // Update objectives
        const internshipObjectives = document.getElementById('internshipObjectives');
        const previewObjectives = document.getElementById('previewObjectives');
        if (internshipObjectives && previewObjectives) {
            previewObjectives.textContent = internshipObjectives.value;
        }
        
        // Update expectations
        const expectations = document.getElementById('expectations');
        const previewExpectations = document.getElementById('previewExpectations');
        if (expectations && previewExpectations) {
            previewExpectations.textContent = expectations.value;
        }
        
        // Update projects
        const projectsWorked = document.getElementById('projectsWorked');
        const previewProjects = document.getElementById('previewProjects');
        if (projectsWorked && previewProjects) {
            previewProjects.textContent = projectsWorked.value;
        }
        
        // Update skills
        const skillsLearned = document.getElementById('skillsLearned');
        const previewSkills = document.getElementById('previewSkills');
        if (skillsLearned && previewSkills) {
            previewSkills.textContent = skillsLearned.value;
        }
        
        // Update challenges
        const challenges = document.getElementById('challenges');
        const previewChallenges = document.getElementById('previewChallenges');
        if (challenges && previewChallenges) {
            previewChallenges.textContent = challenges.value;
        }
        
        // Update achievements
        const achievements = document.getElementById('achievements');
        const previewAchievements = document.getElementById('previewAchievements');
        if (achievements && previewAchievements) {
            previewAchievements.textContent = achievements.value;
        }
        
        // Update courses
        const selectedCourses = document.querySelectorAll('input[name="courses"]:checked');
        const previewCourses = document.getElementById('previewCourses');
        if (selectedCourses.length > 0 && previewCourses) {
            let coursesList = 'The following courses from my academic program were particularly relevant to my internship:\n';
            selectedCourses.forEach(course => {
                coursesList += `- ${course.value}\n`;
            });
            previewCourses.textContent = coursesList;
        }
        
        // Update course relevance
        const courseRelevance = document.getElementById('courseRelevance');
        const previewCourseRelevance = document.getElementById('previewCourseRelevance');
        if (courseRelevance && previewCourseRelevance) {
            previewCourseRelevance.textContent = courseRelevance.value;
        }
    }
    
    // Form submission
    const reportForm = document.getElementById('reportForm');
    if (reportForm) {
        reportForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Report submitted successfully! Your report will be reviewed by the faculty.');
            window.location.href = 'student-reports.html';
        });
    }
    
    // Download report as PDF
    const downloadReportBtn = document.getElementById('downloadReportBtn');
    if (downloadReportBtn) {
        downloadReportBtn.addEventListener('click', function() {
            alert('Downloading report as PDF...');
            // In a real implementation, this would trigger a PDF generation and download
        });
    }
});