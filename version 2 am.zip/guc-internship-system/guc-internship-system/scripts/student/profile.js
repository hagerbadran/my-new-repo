document.addEventListener('DOMContentLoaded', function() {
    // Mobile sidebar toggle (same as dashboard)
    const mobileMenuToggle = document.createElement('button');
    mobileMenuToggle.className = 'mobile-menu-toggle btn primary-btn';
    mobileMenuToggle.innerHTML = '<i class="fas fa-bars"></i> Menu';
    
    const contentHeader = document.querySelector('.content-header');
    if (contentHeader && window.innerWidth < 768) {
        contentHeader.insertBefore(mobileMenuToggle, contentHeader.firstChild);
        
        const sidebar = document.querySelector('.sidebar');
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // Edit buttons functionality
    const editButtons = document.querySelectorAll('.profile-section .btn');
    editButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.closest('.profile-section');
            // TODO: Implement edit functionality
            console.log('Edit button clicked for', section.querySelector('h3').textContent);
        });
    });
    
    // Photo upload functionality
    const changePhotoBtn = document.querySelector('.profile-avatar .btn');
    if (changePhotoBtn) {
        changePhotoBtn.addEventListener('click', function(e) {
            e.preventDefault();
            // TODO: Implement photo upload
            console.log('Change photo clicked');
        });
    }
    
    // Responsive adjustments
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 768 && document.querySelector('.mobile-menu-toggle')) {
            document.querySelector('.mobile-menu-toggle').remove();
            document.querySelector('.sidebar').classList.remove('active');
        }
    });
});