document.addEventListener('DOMContentLoaded', function() {
    // Mobile sidebar toggle
    const mobileMenuToggle = document.createElement('button');
    mobileMenuToggle.className = 'mobile-menu-toggle btn primary-btn';
    mobileMenuToggle.innerHTML = '<i class="fas fa-bars"></i> Menu';
    
    const contentHeader = document.querySelector('.content-header');
    if (contentHeader && window.innerWidth < 768) {
        contentHeader.insertBefore(mobileMenuToggle, contentHeader.firstChild);
        
        const sidebar = document.querySelector('.sidebar');
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // Notification dropdown
    const notificationBtn = document.querySelector('.notification-btn');
    if (notificationBtn) {
        notificationBtn.addEventListener('click', function(e) {
            e.preventDefault();
            // TODO: Implement notification dropdown
            console.log('Notifications clicked');
        });
    }
    
    // User dropdown
    const userDropdown = document.querySelector('.user-dropdown');
    if (userDropdown) {
        userDropdown.addEventListener('click', function() {
            // TODO: Implement user dropdown
            console.log('User dropdown clicked');
        });
    }
    
    // Apply buttons
    const applyButtons = document.querySelectorAll('.internship-card .btn');
    applyButtons.forEach(button => {
        button.addEventListener('click', function() {
            // TODO: Implement apply functionality
            console.log('Apply button clicked');
        });
    });
    
    // Responsive adjustments
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 768 && document.querySelector('.mobile-menu-toggle')) {
            document.querySelector('.mobile-menu-toggle').remove();
            document.querySelector('.sidebar').classList.remove('active');
        }
    });
    
    // Load dummy data
    loadDashboardData();
});

function loadDashboardData() {
    // In a real app, this would be an API call
    console.log('Loading dashboard data...');
    
    // Simulate loading
    setTimeout(() => {
        // Data would be processed here
        console.log('Dashboard data loaded');
    }, 500);
    document.addEventListener('DOMContentLoaded', function() {
    // ...existing code...

    // Profile button
    const profileButton = document.querySelector('.profile-btn');
    if (profileButton) {
        profileButton.addEventListener('click', function() {
            // TODO: Implement profile navigation
            console.log('Profile button clicked');
            window.location.href = '/pages/student/profile.html';
        });
    }

    // Browse Internships button
    const browseInternshipsButton = document.querySelector('.browse-internships-btn');
    if (browseInternshipsButton) {
        browseInternshipsButton.addEventListener('click', function() {
            // TODO: Implement browse internships navigation
            console.log('Browse Internships button clicked');
            window.location.href = '/pages/student/internships.html'; 
        });
    }

    // Logout button functionality
    const logoutButton = document.querySelector('.logout-btn');
    if (logoutButton) {
        logoutButton.addEventListener('click', function () {
            // Clear any session or user data (if applicable)
            localStorage.removeItem('currentUser'); // Example: Clear current user data
            sessionStorage.clear(); // Clear session storage if used

            // Redirect to the index page
            window.location.href = '/pages/index.html';
        });
    }

});
}

<button class="logout-btn btn secondary-btn">
    <i class="fas fa-sign-out-alt"></i> Logout
</button>