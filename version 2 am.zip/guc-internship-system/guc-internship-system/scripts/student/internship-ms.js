document.addEventListener('DOMContentLoaded', function() {
    // Navigation
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.section');
    
    // Dashboard Elements
    const totalInternshipsEl = document.getElementById('total-internships');
    const currentInternshipsEl = document.getElementById('current-internships');
    const completedInternshipsEl = document.getElementById('completed-internships');
    const reportsSubmittedEl = document.getElementById('reports-submitted');
    const activityListEl = document.getElementById('activity-list');
    
    // Internships Elements
    const internshipsListEl = document.getElementById('internships-list');
    const addInternshipBtn = document.getElementById('add-internship-btn');
    const internshipModal = document.getElementById('internship-modal');
    const internshipForm = document.getElementById('internship-form');
    const internshipSearchInput = document.getElementById('internship-search');
    const searchBtn = document.getElementById('search-btn');
    const statusFilter = document.getElementById('status-filter');
    const dateFilter = document.getElementById('date-filter');
    const clearFiltersBtn = document.getElementById('clear-filters');
    
    // Evaluation Elements
    const evaluationModal = document.getElementById('evaluation-modal');
    const evaluationForm = document.getElementById('evaluation-form');
    
    // Internship Details Elements
    const internshipDetailsModal = document.getElementById('internship-details-modal');
    const internshipDetailsContent = document.getElementById('internship-details-content');
    
    // Reports Elements
    const reportsListEl = document.getElementById('reports-list');
    const reportModal = document.getElementById('report-modal');
    const reportForm = document.getElementById('report-form');
    const reportViewModal = document.getElementById('report-view-modal');
    const reportViewContent = document.getElementById('report-view-content');
    
    // Courses Elements
    const coursesListEl = document.getElementById('courses-list');
    
    // Close buttons for modals
    const closeButtons = document.querySelectorAll('.close');
    
    // Data Storage
    let internships = JSON.parse(localStorage.getItem('internships')) || [];
    let evaluations = JSON.parse(localStorage.getItem('evaluations')) || [];
    let reports = JSON.parse(localStorage.getItem('reports')) || [];
    let activities = JSON.parse(localStorage.getItem('activities')) || [];
    
    // Sample courses data (in a real app, this would come from an API)
    const courses = [
        { id: 1, code: 'CS101', title: 'Introduction to Computer Science', description: 'Fundamental concepts of programming and computer systems.' },
        { id: 2, code: 'CS201', title: 'Data Structures', description: 'Implementation and analysis of data structures like arrays, linked lists, stacks, queues, trees, and graphs.' },
        { id: 3, code: 'CS301', title: 'Algorithms', description: 'Design and analysis of algorithms, including sorting, searching, and graph algorithms.' },
        { id: 4, code: 'CS401', title: 'Database Systems', description: 'Concepts and techniques for database design and management.' },
        { id: 5, code: 'CS501', title: 'Software Engineering', description: 'Principles and practices of software development, including requirements, design, testing, and maintenance.' },
        { id: 6, code: 'BUS101', title: 'Introduction to Business', description: 'Overview of business concepts, including management, marketing, and finance.' },
        { id: 7, code: 'BUS201', title: 'Business Communication', description: 'Effective communication in business settings, including writing and presentation skills.' },
        { id: 8, code: 'BUS301', title: 'Project Management', description: 'Principles and practices of project management, including planning, scheduling, and resource allocation.' },
        { id: 9, code: 'MATH101', title: 'Calculus I', description: 'Limits, derivatives, and integrals of algebraic and transcendental functions of one variable.' },
        { id: 10, code: 'MATH201', title: 'Linear Algebra', description: 'Vector spaces, linear transformations, matrices, and determinants.' },
        { id: 11, code: 'ENG101', title: 'Technical Writing', description: 'Writing for technical and professional audiences, including reports, proposals, and documentation.' },
        { id: 12, code: 'ENG201', title: 'Professional Communication', description: 'Oral and written communication for professional settings.' }
    ];
    
    // Initialize the application
    function init() {
        // Set up navigation
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const targetSection = this.getAttribute('data-section');
                
                // Update active nav link
                navLinks.forEach(link => link.classList.remove('active'));
                this.classList.add('active');
                
                // Show target section
                sections.forEach(section => section.classList.remove('active'));
                document.getElementById(targetSection).classList.add('active');
            });
        });
        
        // Set up close buttons for modals
        closeButtons.forEach(button => {
            button.addEventListener('click', function() {
                const modal = this.closest('.modal');
                modal.style.display = 'none';
            });
        });
        
        // Close modals when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });
        
        // Initialize dashboard
        updateDashboard();
        
        // Initialize internships
        renderInternships();
        
        // Initialize reports
        renderReports();
        
        // Initialize courses
        renderCourses();
        
        // Set up event listeners
        setupEventListeners();
    }
    
    // Set up event listeners
    function setupEventListeners() {
        // Add internship button
        addInternshipBtn.addEventListener('click', function() {
            openInternshipModal();
        });
        
        // Internship form submission
        internshipForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveInternship();
        });
        
        // Cancel internship button
        document.getElementById('cancel-internship').addEventListener('click', function() {
            internshipModal.style.display = 'none';
        });
        
        // Evaluation form submission
        evaluationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveEvaluation();
        });
        
        // Cancel evaluation button
        document.getElementById('cancel-evaluation').addEventListener('click', function() {
            evaluationModal.style.display = 'none';
        });
        
        // Report form submission
        reportForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveReport(false);
        });
        
        // Finalize report button
        document.getElementById('finalize-report').addEventListener('click', function() {
            saveReport(true);
        });
        
        // Cancel report button
        document.getElementById('cancel-report').addEventListener('click', function() {
            reportModal.style.display = 'none';
        });
        
        // Close report view button
        document.getElementById('close-report-view').addEventListener('click', function() {
            reportViewModal.style.display = 'none';
        });
        
        // Edit report button
        document.getElementById('edit-report').addEventListener('click', function() {
            const reportId = reportViewContent.getAttribute('data-report-id');
            const report = reports.find(r => r.id === reportId);
            
            if (report && !report.finalized) {
                reportViewModal.style.display = 'none';
                openReportModal(report.internshipId, reportId);
            } else {
                alert('Finalized reports cannot be edited.');
            }
        });
        
        // Print report button
        document.getElementById('print-report').addEventListener('click', function() {
            window.print();
        });
        
        // Search internships
        searchBtn.addEventListener('click', function() {
            filterInternships();
        });
        
        internshipSearchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                filterInternships();
            }
        });
        
        // Filter internships
        statusFilter.addEventListener('change', filterInternships);
        dateFilter.addEventListener('change', filterInternships);
        
        // Clear filters
        clearFiltersBtn.addEventListener('click', function() {
            internshipSearchInput.value = '';
            statusFilter.value = 'all';
            dateFilter.value = '';
            renderInternships();
        });
    }
    
    // Update dashboard statistics and activity
    function updateDashboard() {
        // Update statistics
        totalInternshipsEl.textContent = internships.length;
        currentInternshipsEl.textContent = internships.filter(i => !i.endDate).length;
        completedInternshipsEl.textContent = internships.filter(i => i.endDate).length;
        reportsSubmittedEl.textContent = reports.filter(r => r.finalized).length;
        
        // Update activity list
        if (activities.length === 0) {
            activityListEl.innerHTML = '<p class="empty-state">No recent activity</p>';
        } else {
            activityListEl.innerHTML = '';
            
            // Sort activities by date (newest first)
            activities.sort((a, b) => new Date(b.date) - new Date(a.date));
            
            // Display only the 5 most recent activities
            const recentActivities = activities.slice(0, 5);
            
            recentActivities.forEach(activity => {
                const activityItem = document.createElement('div');
                activityItem.className = 'activity-item';
                
                const activityDate = new Date(activity.date);
                const formattedDate = activityDate.toLocaleDateString() + ' ' + activityDate.toLocaleTimeString();
                
                activityItem.innerHTML = `
                    <p>${activity.description}</p>
                    <span class="activity-time">${formattedDate}</span>
                `;
                
                activityListEl.appendChild(activityItem);
            });
        }
    }
    
    // Render internships list
    function renderInternships(filteredInternships) {
        const internshipsToRender = filteredInternships || internships;
        
        if (internshipsToRender.length === 0) {
            internshipsListEl.innerHTML = '<p class="empty-state">No internships found. Add your first internship!</p>';
            return;
        }
        
        internshipsListEl.innerHTML = '';
        
        internshipsToRender.forEach(internship => {
            const internshipCard = document.createElement('div');
            internshipCard.className = 'internship-card';
            
            const statusClass = internship.endDate ? 'status-completed' : 'status-current';
            const statusText = internship.endDate ? 'Completed' : 'Current Intern';
            
            const startDate = new Date(internship.startDate).toLocaleDateString();
            const endDate = internship.endDate ? new Date(internship.endDate).toLocaleDateString() : 'Present';
            
            internshipCard.innerHTML = `
                <div class="internship-header">
                    <h3>${internship.jobTitle}</h3>
                    <span class="internship-status ${statusClass}">${statusText}</span>
                </div>
                <div class="internship-body">
                    <div class="internship-company">${internship.companyName}</div>
                    <div class="internship-dates">${startDate} - ${endDate}</div>
                    <div class="internship-actions">
                        <button class="action-btn view" data-id="${internship.id}">
                            <i class="fas fa-eye"></i> View Details
                        </button>
                        <div>
                            <button class="action-btn" data-id="${internship.id}" data-action="edit">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="action-btn delete" data-id="${internship.id}" data-action="delete">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            internshipsListEl.appendChild(internshipCard);
            
            // Add event listeners to the buttons
            const viewBtn = internshipCard.querySelector('.action-btn.view');
            viewBtn.addEventListener('click', function() {
                const internshipId = this.getAttribute('data-id');
                openInternshipDetails(internshipId);
            });
            
            const actionBtns = internshipCard.querySelectorAll('.action-btn[data-action]');
            actionBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const internshipId = this.getAttribute('data-id');
                    const action = this.getAttribute('data-action');
                    
                    if (action === 'edit') {
                        openInternshipModal(internshipId);
                    } else if (action === 'delete') {
                        if (confirm('Are you sure you want to delete this internship?')) {
                            deleteInternship(internshipId);
                        }
                    }
                });
            });
        });
    }
    
    // Filter internships based on search and filters
    function filterInternships() {
        const searchTerm = internshipSearchInput.value.toLowerCase();
        const statusValue = statusFilter.value;
        const dateValue = dateFilter.value;
        
        let filteredInternships = [...internships];
        
        // Apply search filter
        if (searchTerm) {
            filteredInternships = filteredInternships.filter(internship => 
                internship.jobTitle.toLowerCase().includes(searchTerm) || 
                internship.companyName.toLowerCase().includes(searchTerm)
            );
        }
        
        // Apply status filter
        if (statusValue !== 'all') {
            if (statusValue === 'current') {
                filteredInternships = filteredInternships.filter(internship => !internship.endDate);
            } else if (statusValue === 'completed') {
                filteredInternships = filteredInternships.filter(internship => internship.endDate);
            }
        }
        
        // Apply date filter
        if (dateValue) {
            const filterDate = new Date(dateValue);
            filteredInternships = filteredInternships.filter(internship => {
                const startDate = new Date(internship.startDate);
                const endDate = internship.endDate ? new Date(internship.endDate) : new Date();
                
                return (startDate <= filterDate && filterDate <= endDate);
            });
        }
        
        renderInternships(filteredInternships);
    }
    
    // Open internship modal for adding or editing
    function openInternshipModal(internshipId) {
        // Reset form
        internshipForm.reset();
        document.getElementById('internship-id').value = '';
        
        if (internshipId) {
            // Edit existing internship
            const internship = internships.find(i => i.id === internshipId);
            
            if (internship) {
                document.getElementById('internship-form-title').textContent = 'Edit Internship';
                document.getElementById('internship-id').value = internship.id;
                document.getElementById('company-name').value = internship.companyName;
                document.getElementById('job-title').value = internship.jobTitle;
                document.getElementById('start-date').value = internship.startDate;
                document.getElementById('end-date').value = internship.endDate || '';
                document.getElementById('description').value = internship.description || '';
            }
        } else {
            // Add new internship
            document.getElementById('internship-form-title').textContent = 'Add New Internship';
        }
        
        internshipModal.style.display = 'block';
    }
    
    // Save internship from form
    function saveInternship() {
        const internshipId = document.getElementById('internship-id').value;
        const companyName = document.getElementById('company-name').value;
        const jobTitle = document.getElementById('job-title').value;
        const startDate = document.getElementById('start-date').value;
        const endDate = document.getElementById('end-date').value || null;
        const description = document.getElementById('description').value;
        
        if (!companyName || !jobTitle || !startDate) {
            alert('Please fill in all required fields.');
            return;
        }
        
        if (endDate && new Date(endDate) < new Date(startDate)) {
            alert('End date cannot be before start date.');
            return;
        }
        
        if (internshipId) {
            // Update existing internship
            const index = internships.findIndex(i => i.id === internshipId);
            
            if (index !== -1) {
                internships[index] = {
                    ...internships[index],
                    companyName,
                    jobTitle,
                    startDate,
                    endDate,
                    description
                };
                
                // Add activity
                addActivity(`Updated internship at ${companyName}`);
            }
        } else {
            // Add new internship
            const newInternship = {
                id: generateId(),
                companyName,
                jobTitle,
                startDate,
                endDate,
                description
            };
            
            internships.push(newInternship);
            
            // Add activity
            addActivity(`Added new internship at ${companyName}`);
        }
        
        // Save to localStorage
        localStorage.setItem('internships', JSON.stringify(internships));
        
        // Close modal
        internshipModal.style.display = 'none';
        
        // Update UI
        renderInternships();
        updateDashboard();
    }
    
    // Delete internship
    function deleteInternship(internshipId) {
        const index = internships.findIndex(i => i.id === internshipId);
        
        if (index !== -1) {
            const internship = internships[index];
            
            // Check if there are reports for this internship
            const hasReports = reports.some(r => r.internshipId === internshipId);
            
            if (hasReports) {
                alert('Cannot delete internship with associated reports. Please delete the reports first.');
                return;
            }
            
            // Remove internship
            internships.splice(index, 1);
            
            // Remove evaluation for this internship
            const evalIndex = evaluations.findIndex(e => e.internshipId === internshipId);
            if (evalIndex !== -1) {
                evaluations.splice(evalIndex, 1);
                localStorage.setItem('evaluations', JSON.stringify(evaluations));
            }
            
            // Add activity
            addActivity(`Deleted internship at ${internship.companyName}`);
            
            // Save to localStorage
            localStorage.setItem('internships', JSON.stringify(internships));
            
            // Update UI
            renderInternships();
            updateDashboard();
        }
    }
    
    // Open internship details
    function openInternshipDetails(internshipId) {
        const internship = internships.find(i => i.id === internshipId);
        
        if (!internship) return;
        
        const evaluation = evaluations.find(e => e.internshipId === internshipId);
        const report = reports.find(r => r.internshipId === internshipId);
        
        const startDate = new Date(internship.startDate).toLocaleDateString();
        const endDate = internship.endDate ? new Date(internship.endDate).toLocaleDateString() : 'Present';
        
        let evaluationHtml = '';
        if (evaluation) {
            const stars = '★'.repeat(evaluation.rating) + '☆'.repeat(5 - evaluation.rating);
            evaluationHtml = `
                <div class="evaluation-section">
                    <h3>Your Evaluation</h3>
                    <div class="rating-display">${stars} (${evaluation.rating}/5)</div>
                    <p>${evaluation.text}</p>
                    <p><strong>Recommendation:</strong> ${evaluation.recommend ? 'Yes, I recommend this internship' : 'No, I do not recommend this internship'}</p>
                    <button class="btn secondary" id="edit-evaluation-btn">Edit Evaluation</button>
                </div>
            `;
        } else if (internship.endDate) {
            evaluationHtml = `
                <div class="evaluation-section">
                    <h3>Evaluation</h3>
                    <p>You haven't evaluated this internship yet.</p>
                    <button class="btn primary" id="add-evaluation-btn">Add Evaluation</button>
                </div>
            `;
        }
        
        let reportHtml = '';
        if (report) {
            const reportStatus = report.finalized ? 'Finalized' : 'Draft';
            reportHtml = `
                <div class="report-section">
                    <h3>Internship Report</h3>
                    <p><strong>Status:</strong> ${reportStatus}</p>
                    <button class="btn primary" id="view-report-btn">View Report</button>
                </div>
            `;
        } else if (internship.endDate) {
            reportHtml = `
                <div class="report-section">
                    <h3>Internship Report</h3>
                    <p>You haven't created a report for this internship yet.</p>
                    <button class="btn primary" id="create-report-btn">Create Report</button>
                </div>
            `;
        }
        
        internshipDetailsContent.innerHTML = `
            <h2>${internship.jobTitle} at ${internship.companyName}</h2>
            <div class="internship-dates"><strong>Duration:</strong> ${startDate} - ${endDate}</div>
            <div class="internship-status ${internship.endDate ? 'status-completed' : 'status-current'}">
                ${internship.endDate ? 'Completed' : 'Current Intern'}
            </div>
            
            <div class="internship-description">
                <h3>Description</h3>
                <p>${internship.description || 'No description provided.'}</p>
            </div>
            
            ${evaluationHtml}
            
            ${reportHtml}
        `;
        
        // Add event listeners
        if (evaluation) {
            const editEvaluationBtn = internshipDetailsContent.querySelector('#edit-evaluation-btn');
            editEvaluationBtn.addEventListener('click', function() {
                internshipDetailsModal.style.display = 'none';
                openEvaluationModal(internshipId);
            });
        } else if (internship.endDate) {
            const addEvaluationBtn = internshipDetailsContent.querySelector('#add-evaluation-btn');
            addEvaluationBtn.addEventListener('click', function() {
                internshipDetailsModal.style.display = 'none';
                openEvaluationModal(internshipId);
            });
        }
        
        if (report) {
            const viewReportBtn = internshipDetailsContent.querySelector('#view-report-btn');
            viewReportBtn.addEventListener('click', function() {
                internshipDetailsModal.style.display = 'none';
                openReportView(report.id);
            });
        } else if (internship.endDate) {
            const createReportBtn = internshipDetailsContent.querySelector('#create-report-btn');
            createReportBtn.addEventListener('click', function() {
                internshipDetailsModal.style.display = 'none';
                openReportModal(internshipId);
            });
        }
        
        internshipDetailsModal.style.display = 'block';
    }
    
    // Open evaluation modal
    function openEvaluationModal(internshipId) {
        // Reset form
        evaluationForm.reset();
        
        const internship = internships.find(i => i.id === internshipId);
        const evaluation = evaluations.find(e => e.internshipId === internshipId);
        
        if (!internship) return;
        
        document.getElementById('evaluation-internship-id').value = internshipId;
        
        if (evaluation) {
            // Pre-fill form with existing evaluation
            document.querySelector(`input[name="rating"][value="${evaluation.rating}"]`).checked = true;
            document.getElementById('evaluation-text').value = evaluation.text;
            document.querySelector(`input[name="recommend"][value="${evaluation.recommend ? 'yes' : 'no'}"]`).checked = true;
        }
        
        evaluationModal.style.display = 'block';
    }
    
    // Save evaluation
    function saveEvaluation() {
        const internshipId = document.getElementById('evaluation-internship-id').value;
        const ratingInput = document.querySelector('input[name="rating"]:checked');
        const text = document.getElementById('evaluation-text').value;
        const recommendInput = document.querySelector('input[name="recommend"]:checked');
        
        if (!ratingInput || !text || !recommendInput) {
            alert('Please fill in all required fields.');
            return;
        }
        
        const rating = parseInt(ratingInput.value);
        const recommend = recommendInput.value === 'yes';
        
        // Check if evaluation already exists
        const existingIndex = evaluations.findIndex(e => e.internshipId === internshipId);
        
        if (existingIndex !== -1) {
            // Update existing evaluation
            evaluations[existingIndex] = {
                ...evaluations[existingIndex],
                rating,
                text,
                recommend,
                updatedAt: new Date().toISOString()
            };
            
            // Add activity
            const internship = internships.find(i => i.id === internshipId);
            addActivity(`Updated evaluation for internship at ${internship.companyName}`);
        } else {
            // Create new evaluation
            const newEvaluation = {
                id: generateId(),
                internshipId,
                rating,
                text,
                recommend,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            
            evaluations.push(newEvaluation);
            
            // Add activity
            const internship = internships.find(i => i.id === internshipId);
            addActivity(`Added evaluation for internship at ${internship.companyName}`);
        }
        
        // Save to localStorage
        localStorage.setItem('evaluations', JSON.stringify(evaluations));
        
        // Close modal
        evaluationModal.style.display = 'none';
        
        // Update UI
        updateDashboard();
    }
    
    // Render reports
    function renderReports() {
        if (reports.length === 0) {
            reportsListEl.innerHTML = '<p class="empty-state">No reports created yet. Select a completed internship to create a report.</p>';
            return;
        }
        
        reportsListEl.innerHTML = '';
        
        reports.forEach(report => {
            const internship = internships.find(i => i.id === report.internshipId);
            
            if (!internship) return;
            
            const reportCard = document.createElement('div');
            reportCard.className = 'report-card';
            
            const statusClass = report.finalized ? 'status-finalized' : 'status-draft';
            const statusText = report.finalized ? 'Finalized' : 'Draft';
            
            const updatedDate = new Date(report.updatedAt).toLocaleDateString();
            
            reportCard.innerHTML = `
                <div class="report-header">
                    <h3>${report.title}</h3>
                    <span class="report-status ${statusClass}">${statusText}</span>
                </div>
                <div class="report-body">
                    <div class="report-company">${internship.companyName}</div>
                    <div class="report-date">Last updated: ${updatedDate}</div>
                    <div class="report-actions">
                        <button class="action-btn view" data-id="${report.id}">
                            <i class="fas fa-eye"></i> View Report
                        </button>
                        <div>
                            ${!report.finalized ? `
                                <button class="action-btn" data-id="${report.id}" data-action="edit">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                            ` : ''}
                            <button class="action-btn delete" data-id="${report.id}" data-action="delete">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            reportsListEl.appendChild(reportCard);
            
            // Add event listeners to the buttons
            const viewBtn = reportCard.querySelector('.action-btn.view');
            viewBtn.addEventListener('click', function() {
                const reportId = this.getAttribute('data-id');
                openReportView(reportId);
            });
            
            const actionBtns = reportCard.querySelectorAll('.action-btn[data-action]');
            actionBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const reportId = this.getAttribute('data-id');
                    const action = this.getAttribute('data-action');
                    
                    if (action === 'edit') {
                        const report = reports.find(r => r.id === reportId);
                        if (report && !report.finalized) {
                            openReportModal(report.internshipId, reportId);
                        }
                    } else if (action === 'delete') {
                        if (confirm('Are you sure you want to delete this report?')) {
                            deleteReport(reportId);
                        }
                    }
                });
            });
        });
    }
    
    // Open report modal for creating or editing
    function openReportModal(internshipId, reportId) {
        // Reset form
        reportForm.reset();
        
        const internship = internships.find(i => i.id === internshipId);
        
        if (!internship) return;
        
        document.getElementById('report-internship-id').value = internshipId;
        document.getElementById('report-id').value = reportId || '';
        
        if (reportId) {
            // Edit existing report
            const report = reports.find(r => r.id === reportId);
            
            if (report) {
                document.getElementById('report-form-title').textContent = 'Edit Internship Report';
                document.getElementById('report-title').value = report.title;
                document.getElementById('report-introduction').value = report.introduction;
                document.getElementById('report-body').value = report.body;
                document.getElementById('report-conclusion').value = report.conclusion || '';
                
                // Disable finalize button if already finalized
                const finalizeBtn = document.getElementById('finalize-report');
                finalizeBtn.disabled = report.finalized;
                finalizeBtn.style.opacity = report.finalized ? '0.5' : '1';
            }
        } else {
            // Create new report
            document.getElementById('report-form-title').textContent = 'Create Internship Report';
            document.getElementById('report-title').value = `${internship.jobTitle} at ${internship.companyName} - Internship Report`;
            
            // Enable finalize button
            const finalizeBtn = document.getElementById('finalize-report');
            finalizeBtn.disabled = false;
            finalizeBtn.style.opacity = '1';
        }
        
        // Populate courses list
        const reportCoursesListEl = document.getElementById('report-courses-list');
        reportCoursesListEl.innerHTML = '';
        
        courses.forEach(course => {
            const courseItem = document.createElement('div');
            courseItem.className = 'checkbox-item';
            
            const isChecked = reportId && reports.find(r => r.id === reportId)?.relatedCourses?.includes(course.id);
            
            courseItem.innerHTML = `
                <input type="checkbox" id="course-${course.id}" name="related-courses" value="${course.id}" ${isChecked ? 'checked' : ''}>
                <label for="course-${course.id}">${course.code} - ${course.title}</label>
            `;
            
            reportCoursesListEl.appendChild(courseItem);
        });
        
        reportModal.style.display = 'block';
    }
    
    // Save report
    function saveReport(finalize) {
        const reportId = document.getElementById('report-id').value;
        const internshipId = document.getElementById('report-internship-id').value;
        const title = document.getElementById('report-title').value;
        const introduction = document.getElementById('report-introduction').value;
        const body = document.getElementById('report-body').value;
        const conclusion = document.getElementById('report-conclusion').value;
        
        if (!title || !introduction || !body) {
            alert('Please fill in all required fields.');
            return;
        }
        
        // Get selected courses
        const selectedCourses = [];
        const courseCheckboxes = document.querySelectorAll('input[name="related-courses"]:checked');
        courseCheckboxes.forEach(checkbox => {
            selectedCourses.push(parseInt(checkbox.value));
        });
        
        if (reportId) {
            // Update existing report
            const index = reports.findIndex(r => r.id === reportId);
            
            if (index !== -1) {
                reports[index] = {
                    ...reports[index],
                    title,
                    introduction,
                    body,
                    conclusion,
                    relatedCourses: selectedCourses,
                    updatedAt: new Date().toISOString(),
                    finalized: finalize || reports[index].finalized
                };
                
                // Add activity
                const internship = internships.find(i => i.id === internshipId);
                addActivity(`Updated report for internship at ${internship.companyName}${finalize ? ' and finalized it' : ''}`);
            }
        } else {
            // Create new report
            const newReport = {
                id: generateId(),
                internshipId,
                title,
                introduction,
                body,
                conclusion,
                relatedCourses: selectedCourses,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                finalized: finalize
            };
            
            reports.push(newReport);
            
            // Add activity
            const internship = internships.find(i => i.id === internshipId);
            addActivity(`Created report for internship at ${internship.companyName}${finalize ? ' and finalized it' : ''}`);
        }
        
        // Save to localStorage
        localStorage.setItem('reports', JSON.stringify(reports));
        
        // Close modal
        reportModal.style.display = 'none';
        
        // Update UI
        renderReports();
        updateDashboard();
        
        // If finalized, show the report view
        if (finalize) {
            const report = reportId ? 
                reports.find(r => r.id === reportId) : 
                reports[reports.length - 1];
            
            openReportView(report.id);
        }
    }
    
    // Delete report
    function deleteReport(reportId) {
        const index = reports.findIndex(r => r.id === reportId);
        
        if (index !== -1) {
            const report = reports[index];
            const internship = internships.find(i => i.id === report.internshipId);
            
            // Remove report
            reports.splice(index, 1);
            
            // Add activity
            addActivity(`Deleted report for internship at ${internship.companyName}`);
            
            // Save to localStorage
            localStorage.setItem('reports', JSON.stringify(reports));
            
            // Update UI
            renderReports();
            updateDashboard();
        }
    }
    
    // Open report view
    function openReportView(reportId) {
        const report = reports.find(r => r.id === reportId);
        
        if (!report) return;
        
        const internship = internships.find(i => i.id === report.internshipId);
        
        if (!internship) return;
        
        // Get related courses
        const relatedCoursesList = report.relatedCourses.map(courseId => {
            const course = courses.find(c => c.id === courseId);
            return course ? `<li>${course.code} - ${course.title}</li>` : '';
        }).join('');
        
        const updatedDate = new Date(report.updatedAt).toLocaleDateString();
        
        reportViewContent.setAttribute('data-report-id', report.id);
        
        reportViewContent.innerHTML = `
            <div class="report-view-header">
                <h2>${report.title}</h2>
                <div class="report-meta">
                    <span class="report-status ${report.finalized ? 'status-finalized' : 'status-draft'}">
                        ${report.finalized ? 'Finalized' : 'Draft'}
                    </span>
                    <span class="report-date">Last updated: ${updatedDate}</span>
                </div>
            </div>
            
            <div class="report-view-content">
                <div class="report-section">
                    <h3>Introduction</h3>
                    <p>${report.introduction}</p>
                </div>
                
                <div class="report-section">
                    <h3>Report Body</h3>
                    <p>${report.body}</p>
                </div>
                
                <div class="report-section">
                    <h3>Conclusion</h3>
                    <p>${report.conclusion || 'No conclusion provided.'}</p>
                </div>
                
                <div class="report-section">
                    <h3>Related Courses</h3>
                    ${relatedCoursesList ? `<ul>${relatedCoursesList}</ul>` : '<p>No related courses selected.</p>'}
                </div>
            </div>
        `;
        
        // Update buttons based on report status
        const editReportBtn = document.getElementById('edit-report');
        editReportBtn.style.display = report.finalized ? 'none' : 'inline-block';
        
        reportViewModal.style.display = 'block';
    }
    
    // Render courses
    function renderCourses() {
        coursesListEl.innerHTML = '';
        
        courses.forEach(course => {
            const courseCard = document.createElement('div');
            courseCard.className = 'course-card';
            
            courseCard.innerHTML = `
                <div class="course-code">${course.code}</div>
                <div class="course-title">${course.title}</div>
                <div class="course-description">${course.description}</div>
            `;
            
            coursesListEl.appendChild(courseCard);
        });
    }
    
    // Add activity
    function addActivity(description) {
        const activity = {
            id: generateId(),
            description,
            date: new Date().toISOString()
        };
        
        activities.push(activity);
        
        // Keep only the last 20 activities
        if (activities.length > 20) {
            activities = activities.slice(-20);
        }
        
        // Save to localStorage
        localStorage.setItem('activities', JSON.stringify(activities));
        
        // Update dashboard
        updateDashboard();
    }
    
    // Generate unique ID
    function generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    }
    
    // Initialize the application
    init();
});
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', event => {
        event.preventDefault();
        const sectionId = link.getAttribute('data-section');

        // Hide all sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });

        // Show the selected section
        document.getElementById(sectionId).classList.add('active');

        // Update active link
        document.querySelectorAll('.nav-link').forEach(nav => {
            nav.classList.remove('active');
        });
        link.classList.add('active');
    });
});