// Dashboard Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Mobile sidebar toggle
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // Notification handling
    const notificationIcon = document.querySelector('.notification-icon');
    if (notificationIcon) {
        notificationIcon.addEventListener('click', function() {
            // Show notifications dropdown (to be implemented)
            console.log('Notifications clicked');
        });
    }
    
    // Chart initialization for dashboard (if needed)
    // This is a placeholder for any charts you might want to add
    function initCharts() {
        // Initialize charts here if needed
    }
    
    // Call chart initialization if needed
    // initCharts();
});