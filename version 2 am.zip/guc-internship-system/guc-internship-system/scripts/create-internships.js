// Create Internship Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Payment type toggle
    const paymentType = document.getElementById('paymentType');
    const salaryGroup = document.getElementById('salaryGroup');
    
    if (paymentType && salaryGroup) {
        paymentType.addEventListener('change', function() {
            if (this.value === 'paid') {
                salaryGroup.style.display = 'block';
            } else {
                salaryGroup.style.display = 'none';
            }
        });
    }
    
    // Form submission
    const createInternshipForm = document.getElementById('createInternshipForm');
    if (createInternshipForm) {
        createInternshipForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const jobTitle = document.getElementById('jobTitle').value;
            const duration = document.getElementById('duration').value;
            const paymentType = document.getElementById('paymentType').value;
            const description = document.getElementById('description').value;
            const responsibilities = document.getElementById('responsibilities').value;
            const qualifications = document.getElementById('qualifications').value;
            const skills = document.getElementById('skills').value;
            
            // Simple validation
            if (!jobTitle || !duration || !paymentType || !description || !responsibilities || !qualifications || !skills) {
                alert('Please fill in all required fields');
                return;
            }
            
            // Show success message and redirect
            alert('Internship created successfully!');
            window.location.href = 'company-internships.html';
        });
    }
});