document.addEventListener('DOMContentLoaded', function () {
    const togglePasswordButtons = document.querySelectorAll('.password-toggle');

    togglePasswordButtons.forEach((button) => {
        button.addEventListener('click', function () {
            const passwordInput = this.previousElementSibling;
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
            this.innerHTML = isPassword ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>';
        });
    });

    // Form submission
    const loginForm = document.getElementById('loginForm');
    const loginButton = document.getElementById('loginButton');

    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            e.preventDefault();

            // Get form values
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const userType = document.getElementById('userType').value;

            // Simple validation
            if (!email || !password || !userType) {
                showAlert('Please fill in all fields', 'error');
                return;
            }

            // Disable button and show loading state
            loginButton.disabled = true;
            loginButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';

            // Simulate API call
            setTimeout(() => {
                // Reset button state
                loginButton.disabled = false;
                loginButton.innerHTML = '<i class="fas fa-sign-in-alt"></i> Login';

                // Check for demo credentials
                if (email === 'student@guc.edu.eg' && password === 'student123') {
                    // Redirect based on user type
                    switch (userType) {
                        case 'student':
                            window.location.href = '../pages/student/dashboard.html';
                            break;
                        case 'company':
                            window.location.href = 'pages/company/dashboard.html';
                            break;
                        case 'scad':
                            window.location.href = 'pages/scad/dashboard.html';
                            break;
                        case 'faculty':
                            window.location.href = 'pages/faculty/dashboard.html';
                            break;
                        default:
                            showAlert('Invalid user type selected', 'error');
                    }
                } else {
                    showAlert('Invalid email or password', 'error');
                }
            }, 1500); // Simulate network delay
        });
    }

    const registerForm = document.getElementById('registerForm');
    const registerButton = document.getElementById('registerButton');

    if (registerForm) {
        registerForm.addEventListener('submit', function (e) {
            e.preventDefault();

            // Get form values
            const fullName = document.getElementById('fullName').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const userType = document.getElementById('userType').value;

            // Validate inputs
            if (!fullName || !email || !password || !userType) {
                showAlert('Please fill in all fields', 'error');
                return;
            }

            // Check if email already exists
            const users = JSON.parse(localStorage.getItem('users')) || [];
            const userExists = users.some((user) => user.email === email);

            if (userExists) {
                showAlert('An account with this email already exists. Please login.', 'error');
                return;
            }

            // Save user data
            const newUser = { fullName, email, password, userType };
            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users));

            showAlert('Account created successfully! Redirecting to login page...', 'success');
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        });
    }

    // Show alert message
    function showAlert(message, type = 'success') {
        // Remove existing alerts
        const existingAlert = document.querySelector('.alert-message');
        if (existingAlert) existingAlert.remove();

        // Create alert element
        const alert = document.createElement('div');
        alert.className = `alert-message alert-${type}`;
        alert.innerHTML = `
            <span>${message}</span>
            <button class="alert-close"><i class="fas fa-times"></i></button>
        `;

        // Add to DOM
        const authHeader = document.querySelector('.auth-header');
        if (authHeader) {
            authHeader.insertAdjacentElement('afterend', alert);
        }

        // Close button functionality
        const closeBtn = alert.querySelector('.alert-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                alert.remove();
            });
        }

        // Auto-remove after 5 seconds
        setTimeout(() => {
            alert.remove();
        }, 5000);
    }
});