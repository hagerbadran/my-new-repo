/**
 * PRO Student Assessment Take functionality
 */

// Assessment data (in a real application, this would be fetched from the server)
const assessmentData = {
    id: 3,
    title: "Leadership Skills Assessment",
    timeLimit: 30, // in minutes
    questions: [
        {
            id: 1,
            text: "Your team is facing a tight deadline for an important project, and you notice that some team members are struggling to complete their tasks. What would be your approach?",
            options: [
                { id: "A", text: "Take over the tasks yourself to ensure they are completed on time." },
                { id: "B", text: "Extend the deadline without consulting stakeholders to give the team more time." },
                { id: "C", text: "Meet with the struggling team members to understand their challenges and provide necessary support or resources." },
                { id: "D", text: "Reassign the tasks to other team members who are more capable without discussing with the original assignees." }
            ],
            correctAnswer: "C"
        },
        {
            id: 2,
            text: "A team member comes to you with a complaint about another colleague. How would you handle this situation?",
            options: [
                { id: "A", text: "Tell them to resolve it themselves as adults." },
                { id: "B", text: "Immediately confront the colleague who is being complained about." },
                { id: "C", text: "Listen to the complaint, gather information from both parties separately, and then facilitate a discussion to resolve the issue." },
                { id: "D", text: "Ignore the complaint to avoid conflict in the team." }
            ],
            correctAnswer: "C"
        },
        {
            id: 3,
            text: "You need to make an important decision that will affect your entire team. What is your approach?",
            options: [
                { id: "A", text: "Make the decision yourself based on what you think is best." },
                { id: "B", text: "Consult with team members, consider their input, and then make an informed decision." },
                { id: "C", text: "Let the team vote on the decision to ensure everyone is happy." },
                { id: "D", text: "Defer the decision to your supervisor to avoid responsibility." }
            ],
            correctAnswer: "B"
        },
        {
            id: 4,
            text: "Your team has just completed a project that didn't meet all its objectives. What would you do?",
            options: [
                { id: "A", text: "Identify who was responsible for the failures and hold them accountable." },
                { id: "B", text: "Move on to the next project without discussing what went wrong." },
                { id: "C", text: "Conduct a retrospective meeting to analyze what went well, what didn't, and how to improve in the future." },
                { id: "D", text: "Blame external factors for the project's shortcomings." }
            ],
            correctAnswer: "C"
        },
        {
            id: 5,
            text: "A team member consistently underperforms despite having the necessary skills. How would you address this?",
            options: [
                { id: "A", text: "Immediately recommend termination to HR." },
                { id: "B", text: "Ignore the issue as long as it doesn't severely impact the team." },
                { id: "C", text: "Have a private conversation to understand any underlying issues, provide feedback, and develop an improvement plan." },
                { id: "D", text: "Publicly criticize their performance to motivate them to do better." }
            ],
            correctAnswer: "C"
        }
        // In a real assessment, there would be 25 questions
        // For brevity, we're only including 5 here
    ]
};

// Assessment state
let currentState = {
    currentQuestion: 1,
    answers: {},
    markedQuestions: {},
    timeRemaining: assessmentData.timeLimit * 60, // in seconds
    timerInterval: null,
    isAssessmentStarted: false
};

document.addEventListener("DOMContentLoaded", () => {
    // Set up event listeners
    setupEventListeners();
});

/**
 * Set up event listeners
 */
function setupEventListeners() {
    // Start assessment button
    const startBtn = document.getElementById('start-assessment-btn');
    if (startBtn) {
        startBtn.addEventListener('click', startAssessment);
    }
    
    // Navigation buttons
    const prevBtn = document.getElementById('prev-question');
    const nextBtn = document.getElementById('next-question');
    
    if (prevBtn) {
        prevBtn.addEventListener('click', () => navigateQuestion(-1));
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => navigateQuestion(1));
    }
    
    // Mark for review checkbox
    const markCheckbox = document.getElementById('mark-for-review');
    if (markCheckbox) {
        markCheckbox.addEventListener('change', toggleMarkForReview);
    }
    
    // Submit assessment button
    const submitBtn = document.getElementById('submit-assessment');
    if (submitBtn) {
        submitBtn.addEventListener('click', showSubmitConfirmation);
    }
    
    // Confirmation modal buttons
    const cancelSubmitBtn = document.getElementById('cancel-submit');
    const confirmSubmitBtn = document.getElementById('confirm-submit');
    
    if (cancelSubmitBtn) {
        cancelSubmitBtn.addEventListener('click', () => {
            document.getElementById('confirmation-modal').classList.remove('show');
        });
    }
    
    if (confirmSubmitBtn) {
        confirmSubmitBtn.addEventListener('click', submitAssessment);
    }
    
    // Time warning modal button
    const continueBtn = document.getElementById('continue-assessment');
    if (continueBtn) {
        continueBtn.addEventListener('click', () => {
            document.getElementById('time-warning-modal').classList.remove('show');
        });
    }
    
    // Close modal buttons
    const closeModalBtns = document.querySelectorAll('.close-modal');
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.modal');
            if (modal) {
                modal.classList.remove('show');
            }
        });
    });
}

/**
 * Start the assessment
 */
function startAssessment() {
    // Hide instructions and show assessment content
    document.querySelector('.assessment-instructions').style.display = 'none';
    document.getElementById('assessment-content').style.display = 'block';
    
    // Initialize the assessment
    initializeAssessment();
    
    // Start the timer
    startTimer();
    
    // Set assessment as started
    currentState.isAssessmentStarted = true;
}

/**
 * Initialize the assessment
 */
function initializeAssessment() {
    // Set total questions
    document.getElementById('total-questions').textContent = assessmentData.questions.length;
    
    // Generate question navigation buttons
    generateQuestionButtons();
    
    // Load the first question
    loadQuestion(1);
}

/**
 * Generate question navigation buttons
 */
function generateQuestionButtons() {
    const buttonsContainer = document.getElementById('question-buttons');
    buttonsContainer.innerHTML = '';
    
    for (let i = 1; i <= assessmentData.questions.length; i++) {
        const button = document.createElement('button');
        button.className = i === 1 ? 'question-button current' : 'question-button';
        button.textContent = i;
        button.setAttribute('data-question', i);
        
        button.addEventListener('click', () => {
            loadQuestion(i);
        });
        
        buttonsContainer.appendChild(button);
    }
}

/**
 * Load a question
 * @param {number} questionNumber - The question number to load
 */
function loadQuestion(questionNumber) {
    // Update current question
    currentState.currentQuestion = questionNumber;
    
    // Get the question data
    const question = assessmentData.questions[questionNumber - 1];
    
    // Update question number and text
    document.getElementById('question-number').textContent = questionNumber;
    document.getElementById('current-question').textContent = questionNumber;
    document.getElementById('question-text').textContent = question.text;
    
    // Update progress bar
    const progressPercentage = (questionNumber / assessmentData.questions.length) * 100;
    document.getElementById('progress-fill').style.width = `${progressPercentage}%`;
    
    // Update answer options
    const optionsContainer = document.getElementById('answer-options');
    optionsContainer.innerHTML = '';
    
    question.options.forEach((option, index) => {
        const optionDiv = document.createElement('div');
        optionDiv.className = 'answer-option';
        
        const input = document.createElement('input');
        input.type = 'radio';
        input.id = `option${index + 1}`;
        input.name = `question${questionNumber}`;
        input.value = option.id;
        
        // Check if this option is selected
        if (currentState.answers[questionNumber] === option.id) {
            input.checked = true;
        }
        
        input.addEventListener('change', () => {
            saveAnswer(questionNumber, option.id);
        });
        
        const label = document.createElement('label');
        label.htmlFor = `option${index + 1}`;
        label.textContent = option.text;
        
        optionDiv.appendChild(input);
        optionDiv.appendChild(label);
        optionsContainer.appendChild(optionDiv);
    });
    
    // Update mark for review checkbox
    const markCheckbox = document.getElementById('mark-for-review');
    markCheckbox.checked = currentState.markedQuestions[questionNumber] || false;
    
    // Update navigation buttons
    const prevBtn = document.getElementById('prev-question');
    const nextBtn = document.getElementById('next-question');
    
    prevBtn.disabled = questionNumber === 1;
    nextBtn.disabled = questionNumber === assessmentData.questions.length;
    
    // Update question navigation buttons
    updateQuestionButtons();
}

/**
 * Save an answer
 * @param {number} questionNumber - The question number
 * @param {string} answer - The selected answer
 */
function saveAnswer(questionNumber, answer) {
    currentState.answers[questionNumber] = answer;
    updateQuestionButtons();
}

/**
 * Toggle mark for review
 */
function toggleMarkForReview() {
    const markCheckbox = document.getElementById('mark-for-review');
    const questionNumber = currentState.currentQuestion;
    
    if (markCheckbox.checked) {
        currentState.markedQuestions[questionNumber] = true;
    } else {
        delete currentState.markedQuestions[questionNumber];
    }
    
    updateQuestionButtons();
}

/**
 * Update question navigation buttons
 */
function updateQuestionButtons() {
    const buttons = document.querySelectorAll('.question-button');
    
    buttons.forEach(button => {
        const questionNumber = parseInt(button.getAttribute('data-question'));
        
        // Reset classes
        button.className = 'question-button';
        
        // Add current class if this is the current question
        if (questionNumber === currentState.currentQuestion) {
            button.classList.add('current');
        }
        
        // Add answered class if this question has been answered
        if (currentState.answers[questionNumber]) {
            button.classList.add('answered');
        }
        
        // Add marked class if this question is marked for review
        if (currentState.markedQuestions[questionNumber]) {
            button.classList.add('marked');
        }
    });
}

/**
 * Navigate to the previous or next question
 * @param {number} direction - The direction to navigate (-1 for previous, 1 for next)
 */
function navigateQuestion(direction) {
    const newQuestionNumber = currentState.currentQuestion + direction;
    
    if (newQuestionNumber >= 1 && newQuestionNumber <= assessmentData.questions.length) {
        loadQuestion(newQuestionNumber);
    }
}

/**
 * Start the timer
 */
function startTimer() {
    // Update timer display
    updateTimerDisplay();
    
    // Start interval
    currentState.timerInterval = setInterval(() => {
        // Decrease time remaining
        currentState.timeRemaining--;
        
        // Update timer display
        updateTimerDisplay();
        
        // Check if time is running out
        if (currentState.timeRemaining === 300) { // 5 minutes remaining
            showTimeWarning();
        }
        
        // Check if time is up
        if (currentState.timeRemaining <= 0) {
            clearInterval(currentState.timerInterval);
            submitAssessment();
        }
    }, 1000);
}

/**
 * Update timer display
 */
function updateTimerDisplay() {
    const minutes = Math.floor(currentState.timeRemaining / 60);
    const seconds = currentState.timeRemaining % 60;
    
    const timerDisplay = document.getElementById('timer');
    timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    // Change color if time is running out
    if (currentState.timeRemaining <= 300) { // 5 minutes or less
        timerDisplay.style.color = '#f44336';
    }
}

/**
 * Show time warning modal
 */
function showTimeWarning() {
    document.getElementById('time-warning-modal').classList.add('show');
}

/**
 * Show submit confirmation modal
 */
function showSubmitConfirmation() {
    // Count unanswered questions
    const answeredCount = Object.keys(currentState.answers).length;
    const unansweredCount = assessmentData.questions.length - answeredCount;
    
    // Show warning if there are unanswered questions
    const unansweredWarning = document.getElementById('unanswered-warning');
    const unansweredCountElement = document.getElementById('unanswered-count');
    
    if (unansweredCount > 0) {
        unansweredWarning.style.display = 'block';
        unansweredCountElement.textContent = unansweredCount;
    } else {
        unansweredWarning.style.display = 'none';
    }
    
    // Show confirmation modal
    document.getElementById('confirmation-modal').classList.add('show');
}

/**
 * Submit the assessment
 */
function submitAssessment() {
    // Stop the timer
    clearInterval(currentState.timerInterval);
    
    // In a real application, this would send the answers to the server for grading
    // For now, we'll just redirect to the results page
    
    // Calculate score (for demo purposes)
    let correctCount = 0;
    
    Object.entries(currentState.answers).forEach(([questionNumber, answer]) => {
        const question = assessmentData.questions[questionNumber - 1];
        if (answer === question.correctAnswer) {
            correctCount++;
        }
    });
    
    const score = Math.round((correctCount / assessmentData.questions.length) * 100);
    
    // Store score in localStorage (for demo purposes)
    localStorage.setItem('assessmentScore', score);
    localStorage.setItem('assessmentId', assessmentData.id);
    
    // Redirect to results page
    window.location.href = 'assessment-results.html?id=' + assessmentData.id;
}