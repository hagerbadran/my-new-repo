/**
 * PRO Student Assessments functionality
 */

document.addEventListener("DOMContentLoaded", () => {
    // Initialize assessments
    initializeAssessments();

    // Set up event listeners
    setupEventListeners();
});

/**
 * Initialize assessments data and UI
 */
function initializeAssessments() {
    // In a real application, this would fetch assessments data from the server
    // For now, we'll use the mock data already in the HTML
}

/**
 * Set up event listeners
 */
function setupEventListeners() {
    // Share/Unshare buttons
    const shareButtons = document.querySelectorAll('.share-btn');
    shareButtons.forEach(btn => {
        btn.addEventListener('click', handleShareToggle);
    });
}

/**
 * Handle share/unshare button click
 * @param {Event} e - The click event
 */
function handleShareToggle(e) {
    const button = e.currentTarget;
    const assessmentId = button.getAttribute('data-id');
    const isShared = button.getAttribute('data-shared') === 'true';
    
    // Toggle shared state
    if (isShared) {
        // Unshare from profile
        button.setAttribute('data-shared', 'false');
        button.textContent = 'Share on Profile';
        showNotification(`Assessment has been removed from your profile`, 'success');
    } else {
        // Share on profile
        button.setAttribute('data-shared', 'true');
        button.textContent = 'Unshare from Profile';
        showNotification(`Assessment has been added to your profile`, 'success');
    }
    
    // In a real application, this would send the updated state to the server
}

/**
 * Show notification
 * @param {string} message - The notification message
 * @param {string} type - The notification type
 */
function showNotification(message, type) {
    // Check if notification container exists
    let notificationContainer = document.querySelector('.notification-container');
    
    // If not, create it
    if (!notificationContainer) {
        notificationContainer = document.createElement('div');
        notificationContainer.className = 'notification-container';
        document.body.appendChild(notificationContainer);
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <p>${message}</p>
        </div>
        <button class="notification-close">&times;</button>
    `;
    
    // Add to container
    notificationContainer.appendChild(notification);
    
    // Add event listener to close button
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.remove();
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}