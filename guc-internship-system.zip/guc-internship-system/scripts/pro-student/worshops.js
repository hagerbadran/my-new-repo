class PROWorkshops {
  constructor() {
    this.loadWorkshops();
    this.initEventListeners();
  }

  async loadWorkshops() {
    const response = await fetch('/api/pro/workshops');
    const workshops = await response.json();
    
    const container = document.getElementById('workshopsList');
    container.innerHTML = workshops.map(workshop => `
      <div class="workshop-card">
        <h3>${workshop.title}</h3>
        <p>${new Date(workshop.date).toLocaleDateString()}</p>
        <button class="btn register-btn" data-id="${workshop.id}">
          ${workshop.registered ? 'Registered' : 'Register'}
        </button>
      </div>
    `).join('');
  }
}