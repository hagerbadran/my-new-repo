/**
 * PRO Student Dashboard functionality
 */

document.addEventListener("DOMContentLoaded", () => {
    // Initialize dashboard
    initializeDashboard();

    // Set up event listeners
    setupEventListeners();

    // Simulate incoming call after 10 seconds
    setTimeout(() => {
        simulateIncomingCall();
    }, 10000);
});

/**
 * Initialize dashboard data and UI
 */
function initializeDashboard() {
    // In a real application, this would fetch data from an API
    // For now, we'll use mock data

    // Update welcome message with user's name
    const username = "Ahmed"; // This would come from the user's session
    const welcomeHeading = document.querySelector(".welcome-content h2");
    if (welcomeHeading) {
        welcomeHeading.textContent = `Welcome, ${username}!`;
    }

    // Check for notifications
    checkNotifications();
}

/**
 * Set up event listeners for dashboard interactions
 */
function setupEventListeners() {
    // Video call controls
    setupVideoCallControls();

    // Share assessment score button
    const shareBtn = document.querySelector('.share-btn');
    if (shareBtn) {
        shareBtn.addEventListener('click', function() {
            const shareStatus = this.parentElement;
            shareStatus.innerHTML = '<span class="shared-badge">Shared on Profile</span>';
            showNotification('Assessment score shared on your profile!', 'success');
        });
    }
}

/**
 * Set up video call controls
 */
function setupVideoCallControls() {
    const joinCallBtn = document.querySelector('.join-call-btn');
    const videoCallModal = document.getElementById('videoCallModal');
    const incomingCallModal = document.getElementById('incomingCallModal');
    const endCallBtn = document.querySelector('.end-call-btn');
    const muteBtn = document.querySelector('.mute-btn');
    const videoBtn = document.querySelector('.video-btn');
    const screenBtn = document.querySelector('.screen-btn');
    const acceptCallBtn = document.querySelector('.accept-call-btn');
    const rejectCallBtn = document.querySelector('.reject-call-btn');
    let callTimer;
    let callDuration = 0;

    // Start Call Timer
    function startCallTimer() {
        const callDurationElement = document.getElementById('callDuration');
        callDuration = 0;
        callTimer = setInterval(() => {
            callDuration++;
            const minutes = String(Math.floor(callDuration / 60)).padStart(2, '0');
            const seconds = String(callDuration % 60).padStart(2, '0');
            callDurationElement.textContent = `${minutes}:${seconds}`;
        }, 1000);
    }

    // Stop Call Timer
    function stopCallTimer() {
        clearInterval(callTimer);
    }

    // Join Call Button
    if (joinCallBtn) {
        joinCallBtn.addEventListener('click', function () {
            videoCallModal.classList.add('show');
            startCallTimer();
        });
    }

    // End Call Button
    if (endCallBtn) {
        endCallBtn.addEventListener('click', function () {
            videoCallModal.classList.remove('show');
            stopCallTimer();
            alert('Call ended');
        });
    }

    // Mute Button
    if (muteBtn) {
        muteBtn.addEventListener('click', function () {
            this.classList.toggle('active');
            const icon = this.querySelector('i');
            if (this.classList.contains('active')) {
                icon.className = 'fas fa-microphone-slash';
                alert('Microphone muted');
            } else {
                icon.className = 'fas fa-microphone';
                alert('Microphone unmuted');
            }
        });
    }

    // Video Button
    if (videoBtn) {
        videoBtn.addEventListener('click', function () {
            this.classList.toggle('active');
            const icon = this.querySelector('i');
            if (this.classList.contains('active')) {
                icon.className = 'fas fa-video-slash';
                alert('Video disabled');
            } else {
                icon.className = 'fas fa-video';
                alert('Video enabled');
            }
        });
    }

    // Screen Share Button
    if (screenBtn) {
        screenBtn.addEventListener('click', function () {
            alert('Screen sharing started');
        });
    }

    // Accept Call Button
    if (acceptCallBtn) {
        acceptCallBtn.addEventListener('click', function () {
            incomingCallModal.classList.remove('show');
            videoCallModal.classList.add('show');
            startCallTimer();
        });
    }

    // Reject Call Button
    if (rejectCallBtn) {
        rejectCallBtn.addEventListener('click', function () {
            incomingCallModal.classList.remove('show');
            alert('Call declined');
        });
    }
}

/**
 * Check for notifications and display them
 */
function checkNotifications() {
    // In a real application, this would check for new notifications from an API
    // For now, we'll simulate a notification

    setTimeout(() => {
        showNotification('Welcome back! You have a new workshop available.', 'info');
    }, 2000);
}

/**
 * Show a notification
 * @param {string} message - The notification message
 * @param {string} type - The notification type (info, success, warning, error)
 */
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <p>${message}</p>
        </div>
        <button class="notification-close">&times;</button>
    `;

    // Add to container (create if it doesn't exist)
    let container = document.querySelector('.notification-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'notification-container';
        document.body.appendChild(container);
    }

    container.appendChild(notification);

    // Add close button functionality
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.remove();
    });

    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

/**
 * Simulate an incoming call
 */
function simulateIncomingCall() {
    const incomingCallModal = document.getElementById('incomingCallModal');
    if (incomingCallModal) {
        incomingCallModal.classList.add('show');
        
        // Play ringtone (in a real app)
        // const ringtone = new Audio('../../assets/sounds/ringtone.mp3');
        // ringtone.loop = true;
        // ringtone.play();
    }
}

// Call timer variables
let callTimer;
let callSeconds = 0;

/**
 * Start the call timer
 */
function startCallTimer() {
    callSeconds = 0;
    updateCallDuration();
    callTimer = setInterval(updateCallDuration, 1000);
}

/**
 * Stop the call timer
 */
function stopCallTimer() {
    clearInterval(callTimer);
    callSeconds = 0;
    updateCallDuration();
}

/**
 * Update the call duration display
 */
function updateCallDuration() {
    callSeconds++;
    const minutes = Math.floor(callSeconds / 60);
    const seconds = callSeconds % 60;
    const durationElement = document.getElementById('callDuration');
    if (durationElement) {
        durationElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
}