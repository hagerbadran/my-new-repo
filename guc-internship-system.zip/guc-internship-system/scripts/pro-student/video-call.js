class VideoCallSystem {
  constructor() {
    this.localStream = null;
    this.peerConnection = null;
    this.initCall();
    this.initControls();
  }

  async initCall() {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
      
      document.getElementById('localVideo').srcObject = this.localStream;
      
      // Initialize WebRTC connection
      this.setupPeerConnection();
      
    } catch (error) {
      console.error('Error accessing media devices:', error);
    }
  }

  setupPeerConnection() {
    this.peerConnection = new RTCPeerConnection();
    
    // Add local stream to connection
    this.localStream.getTracks().forEach(track => {
      this.peerConnection.addTrack(track, this.localStream);
    });
    
    // Handle remote stream
    this.peerConnection.ontrack = (event) => {
      document.getElementById('remoteVideo').srcObject = event.streams[0];
    };
  }
}