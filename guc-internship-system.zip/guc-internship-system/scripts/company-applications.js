// Company Applications Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality for company applications
    const searchCompany = document.getElementById('searchCompany');
    if (searchCompany) {
        searchCompany.addEventListener('input', function() {
            filterCompanyApplications();
        });
    }
    
    // Filter functionality
    const industryFilter = document.getElementById('industryFilter');
    
    if (industryFilter) {
        industryFilter.addEventListener('change', filterCompanyApplications);
    }
    
    // Filter company applications based on search and filter values
    function filterCompanyApplications() {
        const searchValue = searchCompany ? searchCompany.value.toLowerCase() : '';
        const industryValue = industryFilter ? industryFilter.value.toLowerCase() : '';
        
        const applicationItems = document.querySelectorAll('.company-application-item');
        
        applicationItems.forEach(item => {
            const companyName = item.querySelector('.company-details h3').textContent.toLowerCase();
            const industry = item.querySelector('.company-details p').textContent.toLowerCase();
            
            // Check if the item matches all filters
            const matchesSearch = searchValue === '' || companyName.includes(searchValue);
            const matchesIndustry = industryValue === '' || industry.includes(industryValue);
            
            // Show or hide the item based on filter matches
            if (matchesSearch && matchesIndustry) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    // Approve/Reject company application
    const approveButtons = document.querySelectorAll('.success-btn');
    const rejectButtons = document.querySelectorAll('.danger-btn');
    
    approveButtons.forEach(button => {
        if (button.textContent.trim() === 'Approve') {
            button.addEventListener('click', function() {
                const applicationItem = this.closest('.company-application-item');
                if (applicationItem) {
                    const companyName = applicationItem.querySelector('.company-details h3').textContent;
                    
                    const confirmed = confirm(`Are you sure you want to approve ${companyName}'s application?`);
                    
                    if (confirmed) {
                        // Remove the application item
                        applicationItem.remove();
                        
                        // Show success message
                        alert(`${companyName}'s application has been approved.`);
                    }
                }
            });
        }
    });
    
    rejectButtons.forEach(button => {
        if (button.textContent.trim() === 'Reject') {
            button.addEventListener('click', function() {
                const applicationItem = this.closest('.company-application-item');
                if (applicationItem) {
                    const companyName = applicationItem.querySelector('.company-details h3').textContent;
                    
                    const confirmed = confirm(`Are you sure you want to reject ${companyName}'s application?`);
                    
                    if (confirmed) {
                        // Remove the application item
                        applicationItem.remove();
                        
                        // Show success message
                        alert(`${companyName}'s application has been rejected.`);
                    }
                }
            });
        }
    });
});
