/**
 * Faculty Report Review functionality
 */

document.addEventListener("DOMContentLoaded", () => {
    // Initialize form
    initializeForm();

    // Set up event listeners
    setupEventListeners();
});

/**
 * Initialize form elements and data
 */
function initializeForm() {
    // In a real application, this would fetch the report data from the server
    // For now, we'll use the mock data already in the HTML
}

/**
 * Set up event listeners
 */
function setupEventListeners() {
    // Form submission
    const reviewForm = document.getElementById('report-review-form');
    if (reviewForm) {
        reviewForm.addEventListener('submit', handleFormSubmit);
    }
    
    // Status radio buttons
    const statusRadios = document.querySelectorAll('input[name="report-status"]');
    statusRadios.forEach(radio => {
        radio.addEventListener('change', handleStatusChange);
    });
    
    // Success modal buttons
    const goToDashboardBtn = document.getElementById('go-to-dashboard');
    if (goToDashboardBtn) {
        goToDashboardBtn.addEventListener('click', () => {
            window.location.href = 'dashboard.html';
        });
    }
    
    const reviewNextBtn = document.getElementById('review-next');
    if (reviewNextBtn) {
        reviewNextBtn.addEventListener('click', () => {
            window.location.href = 'reports.html';
        });
    }
    
    // Close modal buttons
    const closeModalBtns = document.querySelectorAll('.close-modal');
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.modal');
            if (modal) {
                modal.classList.remove('show');
            }
        });
    });
}

/**
 * Handle form submission
 * @param {Event} e - The submit event
 */
function handleFormSubmit(e) {
    e.preventDefault();
    
    // Validate form
    if (!validateForm()) {
        return;
    }
    
    // In a real application, this would send the form data to the server
    // For now, we'll just show a success message
    
    // Show success modal
    document.getElementById('success-modal').classList.add('show');
}

/**
 * Handle status change
 */
function handleStatusChange() {
    const selectedStatus = document.querySelector('input[name="report-status"]:checked').value;
    const commentsTextarea = document.getElementById('review-comments');
    
    // If status is flag or reject, make comments required
    if (selectedStatus === 'flag' || selectedStatus === 'reject') {
        commentsTextarea.setAttribute('required', '');
        commentsTextarea.placeholder = `Please provide reasons for ${selectedStatus === 'flag' ? 'flagging' : 'rejecting'} the report...`;
    } else {
        commentsTextarea.removeAttribute('required');
        commentsTextarea.placeholder = 'Provide feedback, comments, or reasons for flagging/rejecting the report...';
    }
}

/**
 * Validate form
 * @returns {boolean} - Whether the form is valid
 */
function validateForm() {
    let isValid = true;
    
    // Check if status is selected
    const statusSelected = document.querySelector('input[name="report-status"]:checked');
    if (!statusSelected) {
        document.querySelector('.status-options').classList.add('error');
        showNotification('Please select a report status', 'error');
        isValid = false;
    } else {
        document.querySelector('.status-options').classList.remove('error');
        
        // If status is flag or reject, check if comments are provided
        if ((statusSelected.value === 'flag' || statusSelected.value === 'reject')) {
            const comments = document.getElementById('review-comments').value.trim();
            if (!comments) {
                document.getElementById('review-comments').classList.add('error');
                showNotification(`Please provide reasons for ${statusSelected.value === 'flag' ? 'flagging' : 'rejecting'} the report`, 'error');
                isValid = false;
            } else {
                document.getElementById('review-comments').classList.remove('error');
            }
        }
    }
    
    return isValid;
}

/**
 * Show notification
 * @param {string} message - The notification message
 * @param {string} type - The notification type
 */
function showNotification(message, type) {
    // Check if notification container exists
    let notificationContainer = document.querySelector('.notification-container');
    
    // If not, create it
    if (!notificationContainer) {
        notificationContainer = document.createElement('div');
        notificationContainer.className = 'notification-container';
        document.body.appendChild(notificationContainer);
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <p>${message}</p>
        </div>
        <button class="notification-close">&times;</button>
    `;
    
    // Add to container
    notificationContainer.appendChild(notification);
    
    // Add event listener to close button
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.remove();
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}