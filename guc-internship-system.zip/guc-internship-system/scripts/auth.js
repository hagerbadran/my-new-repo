document.addEventListener('DOMContentLoaded', function () {
    // Password toggle functionality
    const togglePasswordButtons = document.querySelectorAll('.password-toggle');
    togglePasswordButtons.forEach((button) => {
        button.addEventListener('click', function () {
            const passwordInput = document.getElementById(this.dataset.target);
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
            this.innerHTML = isPassword ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>';
        });
    });

    // Login form submission
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            e.preventDefault();

            // Get form values
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const userType = document.getElementById('userType').value;

            // Validate inputs
            if (!email || !password || !userType) {
                showAlert('Please fill in all fields', 'error');
                return;
            }

            // Simulate login logic
            const users = JSON.parse(localStorage.getItem('users')) || [];
            const user = users.find((u) => u.email === email && u.password === password && u.userType === userType);

            if (user) {
                // Save current user to localStorage
                localStorage.setItem('currentUser', JSON.stringify(user));

                // Redirect based on user type
                switch (userType) {
                    case 'student':
                        window.location.href = '../../pages/student/dashboard.html';
                        break;
                    case 'company':
                        window.location.href = '../pages/company/dashboard.html';
                        break;
                    case 'scad':
                        window.location.href = '../pages/scad/dashboard.html';
                        break;
                    case 'faculty':
                        window.location.href = '../pages/faculty/dashboard.html';
                        break;
                    default:
                        showAlert('Invalid user type selected', 'error');
                }
            } else {
                showAlert('Invalid email or password', 'error');
            }
        });
    }

    // Registration form submission
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function (e) {
            e.preventDefault();

            // Get form values
            const fullName = document.getElementById('fullName').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const userType = document.getElementById('userType').value;

            // Validate inputs
            if (!fullName || !email || !password || !confirmPassword || !userType) {
                showAlert('Please fill in all fields', 'error');
                return;
            }

            if (password !== confirmPassword) {
                showAlert('Passwords do not match', 'error');
                return;
            }

            // Check if email already exists
            const users = JSON.parse(localStorage.getItem('users')) || [];
            const userExists = users.some((user) => user.email === email);

            if (userExists) {
                showAlert('An account with this email already exists. Please login.', 'error');
                return;
            }

            // Save new user
            const newUser = { fullName, email, password, userType };
            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users));

            showAlert('Account created successfully! Redirecting to login page...', 'success');
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        });
    }

    // Show alert message
    function showAlert(message, type = 'success') {
        // Remove existing alerts
        const existingAlert = document.querySelector('.alert-message');
        if (existingAlert) existingAlert.remove();

        // Create alert element
        const alert = document.createElement('div');
        alert.className = `alert-message alert-${type}`;
        alert.innerHTML = `
            <span>${message}</span>
            <button class="alert-close"><i class="fas fa-times"></i></button>
        `;

        // Add to DOM
        const authHeader = document.querySelector('.auth-header');
        if (authHeader) {
            authHeader.insertAdjacentElement('afterend', alert);
        }

        // Close button functionality
        const closeBtn = alert.querySelector('.alert-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                alert.remove();
            });
        }

        // Auto-remove after 5 seconds
        setTimeout(() => {
            alert.remove();
        }, 5000);
    }
});