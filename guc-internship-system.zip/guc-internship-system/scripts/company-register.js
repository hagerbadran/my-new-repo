document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('companyRegisterForm');
    const passwordToggle = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    const logoUpload = document.getElementById('logoUpload');
    const fileName = document.getElementById('fileName');

    // Password toggle
    if (passwordToggle && passwordInput) {
        passwordToggle.addEventListener('click', function() {
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
            this.innerHTML = isPassword ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>';
        });
    }

    // File upload display
    if (logoUpload && fileName) {
        logoUpload.addEventListener('change', function() {
            if (this.files.length > 0) {
                fileName.textContent = this.files[0].name;
            } else {
                fileName.textContent = 'Choose file (PNG, JPG max 2MB)';
            }
        });
    }

    // Form validation
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const companyName = document.getElementById('companyName').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const email = document.getElementById('email').value.trim();
            const industry = document.getElementById('industry').value;
            const companySize = document.getElementById('companySize').value;
            const termsAgreement = document.getElementById('termsAgreement').checked;
            const logoFile = document.getElementById('companyLogo').files[0];


            // Reset error messages
            resetErrors();

            let hasErrors = false;

            // Validate Company Name
            if (!companyName) {
                setError('companyName', 'Company Name is required');
                hasErrors = true;
            }

            // Validate Industry
            if (!industry) {
                setError('industry', 'Industry is required');
                hasErrors = true;
            }

            // Validate Company Size
            if (!companySize) {
                setError('companySize', 'Company Size is required');
                hasErrors = true;
            }

           // Validate Email
            if (!email) {
                setError('email', 'Email is required');
                hasErrors = true;
            } else if (!isValidEmail(email)) {
                setError('email', 'Invalid email format');
                hasErrors = true;
            }

            // Validate Password
            if (!password) {
                setError('password', 'Password is required');
                hasErrors = true;
            } else if (password.length < 8) {
                setError('password', 'Password must be at least 8 characters');
                hasErrors = true;
            }

            // Validate Confirm Password
            if (!confirmPassword) {
                setError('confirmPassword', 'Confirm Password is required');
                hasErrors = true;
            } else if (password !== confirmPassword) {
                setError('confirmPassword', 'Passwords do not match');
                hasErrors = true;
            }

            // Validate Terms Agreement
            if (!termsAgreement) {
                setError('termsAgreement', 'You must agree to the terms');
                hasErrors = true;
            }

             // Validate Logo File Size and Type
            if (logoFile) {
                const maxSizeInBytes = 2 * 1024 * 1024; // 2MB
                const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];

                if (logoFile.size > maxSizeInBytes) {
                    setError('companyLogo', 'Logo file size must be less than 2MB');
                    hasErrors = true;
                }

                if (!allowedTypes.includes(logoFile.type)) {
                    setError('companyLogo', 'Invalid file type. Only JPG, JPEG, and PNG are allowed.');
                    hasErrors = true;
                }
            }


            if (hasErrors) {
                return; // Stop submission if there are errors
            }

            // Simulate form submission
            console.log('Form Data:', {
                companyName,
                industry,
                companySize,
                email,
                password,
                confirmPassword,
                termsAgreement,
                logoFile
            });

            // Simulate API call
            const submitBtn = document.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Registering...';
            submitBtn.disabled = true;

            setTimeout(() => {
                // Reset button
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                
                // Show success message
                showAlert('Registration successful! Your application is under review.', 'success');
                
                // Redirect after delay
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 2000);
            }, 1500);
        });
    }
    
    function showAlert(message, type) {
        // Remove existing alerts
        const existingAlert = document.querySelector('.alert-message');
        if (existingAlert) existingAlert.remove();
        
        // Create alert
        const alert = document.createElement('div');
        alert.className = `alert-message alert-${type}`;
        alert.innerHTML = `
            <span>${message}</span>
            <button class="alert-close"><i class="fas fa-times"></i></button>
        `;
        
        // Add to form
        form.prepend(alert);
        
        // Close button
        const closeBtn = alert.querySelector('.alert-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                alert.remove();
            });
        }
        
        // Auto-remove
        setTimeout(() => {
            alert.remove();
        }, 5000);
    }

    function resetErrors() {
        const errorElements = document.querySelectorAll('.error-message');
        errorElements.forEach(el => el.remove());
        const inputElements = document.querySelectorAll('.form-group input, .form-group select, .form-group textarea');
        inputElements.forEach(el => el.classList.remove('error-input'));
    }

    function setError(fieldId, message) {
        const field = document.getElementById(fieldId);
        if (!field) return;

        field.classList.add('error-input');
        
        let errorLabel = document.createElement('label');
        errorLabel.className = 'error-message';
        errorLabel.textContent = message;
        
        // Check if an error message already exists for this field
        let existingErrorLabel = field.nextElementSibling;
        if (existingErrorLabel && existingErrorLabel.classList.contains('error-message')) {
            existingErrorLabel.textContent = message; // Update the existing error message
        } else {
            // Insert the error message after the input field
             field.parentNode.appendChild(errorLabel);
        }
       
    }

    function isValidEmail(email) {
        const emailRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        return emailRegex.test(email);
    }
});
