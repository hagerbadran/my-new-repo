// Applications Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchApplication = document.getElementById('searchApplication');
    if (searchApplication) {
        searchApplication.addEventListener('input', function() {
            filterApplications();
        });
    }
    
    // Filter functionality
    const statusFilter = document.getElementById('statusFilter');
    const internshipFilter = document.getElementById('internshipFilter');
    
    if (statusFilter) {
        statusFilter.addEventListener('change', filterApplications);
    }
    
    if (internshipFilter) {
        internshipFilter.addEventListener('change', filterApplications);
    }
    
    // Filter applications based on search and filter values
    function filterApplications() {
        const searchValue = searchApplication ? searchApplication.value.toLowerCase() : '';
        const statusValue = statusFilter ? statusFilter.value.toLowerCase() : '';
        const internshipValue = internshipFilter ? internshipFilter.value.toLowerCase() : '';
        
        const applicationItems = document.querySelectorAll('.application-item');
        
        applicationItems.forEach(item => {
            let title = '';
            let company = '';
            let status = '';
            let internship = '';
            
            // For student applications
            const companyDetails = item.querySelector('.company-details');
            if (companyDetails) {
                title = companyDetails.querySelector('h3').textContent.toLowerCase();
                company = companyDetails.querySelector('p').textContent.toLowerCase();
            }
            
            // For company applications
            const studentDetails = item.querySelector('.student-details');
            if (studentDetails) {
                title = studentDetails.querySelector('h3').textContent.toLowerCase();
            }
            
            const internshipDetails = item.querySelector('.application-internship');
            if (internshipDetails) {
                internship = internshipDetails.querySelector('h4').textContent.toLowerCase();
            }
            
            // Get status
            const statusBadge = item.querySelector('.status-badge');
            if (statusBadge) {
                status = statusBadge.textContent.toLowerCase();
            }
            
            // Check if the item matches all filters
            const matchesSearch = searchValue === '' || 
                                 title.includes(searchValue) || 
                                 company.includes(searchValue) ||
                                 internship.includes(searchValue);
            
            const matchesStatus = statusValue === '' || status.includes(statusValue);
            
            const matchesInternship = internshipValue === '' || 
                                     internship.includes(internshipValue);
            
            // Show or hide the item based on filter matches
            if (matchesSearch && matchesStatus && matchesInternship) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    // Company application details modal
    window.showCompanyDetails = function(companyName) {
        const modal = document.getElementById('companyDetailsModal');
        const modalCompanyName = document.getElementById('modalCompanyName');
        
        if (modal && modalCompanyName) {
            modalCompanyName.textContent = companyName;
            modal.style.display = 'block';
            
            // Prevent body scrolling
            document.body.style.overflow = 'hidden';
        }
    };
    
    window.closeCompanyDetails = function() {
        const modal = document.getElementById('companyDetailsModal');
        
        if (modal) {
            modal.style.display = 'none';
            
            // Re-enable body scrolling
            document.body.style.overflow = 'auto';
        }
    };
    
    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
        const modal = document.getElementById('companyDetailsModal');
        
        if (modal && e.target === modal) {
            closeCompanyDetails();
        }
    });
});