// scripts/company/internship-form.js
class InternshipForm {
  constructor() {
    this.form = document.getElementById('internshipForm');
    this.init();
  }

  init() {
    this.form.addEventListener('submit', this.handleSubmit.bind(this));
    this.initSkillTags();
  }

  initSkillTags() {
    const tagContainer = document.getElementById('skillTags');
    const skills = ['JavaScript', 'React', 'Python', 'UI/UX'];
    
    skills.forEach(skill => {
      const tag = document.createElement('div');
      tag.className = 'skill-tag';
      tag.innerHTML = `
        <input type="checkbox" id="skill-${skill}" name="skills" value="${skill}">
        <label for="skill-${skill}">${skill}</label>
      `;
      tagContainer.appendChild(tag);
    });
  }

  handleSubmit(e) {
    e.preventDefault();
    const formData = new FormData(this.form);
    const internshipData = {
      title: formData.get('title'),
      description: formData.get('description'),
      skills: formData.getAll('skills'),
      isPaid: formData.get('isPaid') === 'on'
    };
    
    InternshipService.create(internshipData)
      .then(() => {
        window.location.href = 'internships.html';
      });
  }
}