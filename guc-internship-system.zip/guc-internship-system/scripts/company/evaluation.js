class EvaluationSystem {
  constructor() {
    this.studentId = new URLSearchParams(window.location.search).get('studentId');
    this.initStars();
    this.loadStudentData();
    this.initForm();
  }

  async loadStudentData() {
    const response = await fetch(`/api/students/${this.studentId}`);
    const data = await response.json();
    document.getElementById('studentName').textContent = data.name;
  }

  initStars() {
    const stars = document.querySelectorAll('.rating-stars .star');
    stars.forEach((star, index) => {
      star.addEventListener('click', () => {
        stars.forEach((s, i) => {
          s.classList.toggle('active', i <= index);
        });
        document.getElementById('technicalRating').value = index + 1;
      });
    });
  }

  initForm() {
    document.getElementById('evaluationForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const evaluationData = {
        studentId: this.studentId,
        technicalRating: document.getElementById('technicalRating').value,
        strengths: document.getElementById('strengths').value,
        improvements: document.getElementById('improvements').value,
        recommendHiring: document.getElementById('recommendHiring').checked
      };
      
      try {
        const response = await fetch('/api/evaluations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(evaluationData)
        });
        
        if (response.ok) {
          window.location.href = 'evaluation-confirmation.html';
        }
      } catch (error) {
        console.error('Evaluation submission failed:', error);
      }
    });
  }
}