// Internships Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInput = document.getElementById('searchInternship');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            filterInternships();
        });
    }
    
    // Filter functionality
    const industryFilter = document.getElementById('industryFilter');
    const durationFilter = document.getElementById('durationFilter');
    const paymentFilter = document.getElementById('paymentFilter');
    
    if (industryFilter) {
        industryFilter.addEventListener('change', filterInternships);
    }
    
    if (durationFilter) {
        durationFilter.addEventListener('change', filterInternships);
    }
    
    if (paymentFilter) {
        paymentFilter.addEventListener('change', filterInternships);
    }
    
    // Reset filters
    const resetFiltersBtn = document.getElementById('resetFilters');
    if (resetFiltersBtn) {
        resetFiltersBtn.addEventListener('click', function() {
            if (searchInput) searchInput.value = '';
            if (industryFilter) industryFilter.value = '';
            if (durationFilter) durationFilter.value = '';
            if (paymentFilter) paymentFilter.value = '';
            
            filterInternships();
        });
    }
    
    // Filter internships based on search and filter values
    function filterInternships() {
        const searchValue = searchInput ? searchInput.value.toLowerCase() : '';
        const industryValue = industryFilter ? industryFilter.value.toLowerCase() : '';
        const durationValue = durationFilter ? durationFilter.value : '';
        const paymentValue = paymentFilter ? paymentFilter.value : '';
        
        const internshipItems = document.querySelectorAll('.internship-item');
        let visibleCount = 0;
        
        internshipItems.forEach(item => {
            const title = item.querySelector('h3').textContent.toLowerCase();
            const company = item.querySelector('p').textContent.toLowerCase();
            
            // Get duration and payment info from meta spans
            const metaSpans = item.querySelectorAll('.internship-meta span');
            let duration = '';
            let payment = '';
            
            metaSpans.forEach(span => {
                const text = span.textContent.toLowerCase();
                if (text.includes('month')) {
                    duration = text;
                }
                if (text.includes('paid') || text.includes('unpaid')) {
                    payment = text;
                }
            });
            
            // Check if the item matches all filters
            const matchesSearch = searchValue === '' || 
                                 title.includes(searchValue) || 
                                 company.includes(searchValue);
            
            const matchesIndustry = industryValue === '' || 
                                   company.includes(industryValue);
            
            const matchesDuration = durationValue === '' || 
                                   (durationValue === '1-2' && duration.includes('1') || duration.includes('2')) ||
                                   (durationValue === '3-4' && duration.includes('3') || duration.includes('4')) ||
                                   (durationValue === '5-6' && duration.includes('5') || duration.includes('6')) ||
                                   (durationValue === '6+' && parseInt(duration) >= 6);
            
            const matchesPayment = paymentValue === '' || 
                                  (paymentValue === 'paid' && payment.includes('paid') && !payment.includes('unpaid')) ||
                                  (paymentValue === 'unpaid' && payment.includes('unpaid'));
            
            // Show or hide the item based on filter matches
            if (matchesSearch && matchesIndustry && matchesDuration && matchesPayment) {
                item.style.display = 'flex';
                visibleCount++;
            } else {
                item.style.display = 'none';
            }
        });
        
        // Update results count
        const resultsCount = document.getElementById('resultsCount');
        if (resultsCount) {
            resultsCount.textContent = visibleCount;
        }
    }
    
    // Pagination functionality
    const paginationBtns = document.querySelectorAll('.pagination-btn');
    if (paginationBtns.length > 0) {
        paginationBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                paginationBtns.forEach(b => b.classList.remove('active'));
                
                // Add active class to clicked button
                this.classList.add('active');
                
                // Here you would normally load the next page of results
                // For this prototype, we'll just scroll to top
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }
});