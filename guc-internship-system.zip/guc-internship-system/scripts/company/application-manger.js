class ApplicationManager {
  constructor() {
    this.applicationId = new URLSearchParams(window.location.search).get('id');
    this.loadApplicationData();
    this.initEventHandlers();
  }

  async loadApplicationData() {
    const response = await fetch(`/api/applications/${this.applicationId}`);
    const data = await response.json();
    
    document.getElementById('applicantName').textContent = data.student.name;
    document.getElementById('applicantMajor').textContent = data.student.major;
    document.getElementById('applicantSemester').textContent = data.student.semester;
    document.getElementById('statusSelect').value = data.status;
  }

  initEventHandlers() {
    document.getElementById('saveStatus').addEventListener('click', async () => {
      const newStatus = document.getElementById('statusSelect').value;
      
      const response = await fetch(`/api/applications/${this.applicationId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      
      if (response.ok) {
        alert('Status updated successfully!');
      }
    });
  }
}