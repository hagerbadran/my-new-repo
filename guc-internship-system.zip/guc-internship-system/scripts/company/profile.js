// Profile Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Tab functionality
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    if (tabButtons.length > 0 && tabContents.length > 0) {
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons and contents
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Add active class to clicked button
                this.classList.add('active');
                
                // Show corresponding content
                const tabId = this.getAttribute('data-tab');
                document.getElementById(tabId).classList.add('active');
            });
        });
    }
    
    // Edit profile button
    const editProfileBtn = document.querySelector('.edit-profile-btn');
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', function() {
            // Toggle edit mode for profile details
            const detailValues = document.querySelectorAll('.detail-value');
            
            detailValues.forEach(value => {
                const currentText = value.textContent;
                const input = document.createElement('input');
                input.type = 'text';
                input.value = currentText;
                input.className = 'edit-input';
                
                // Replace text with input
                value.innerHTML = '';
                value.appendChild(input);
            });
            
            // Change button text and functionality
            this.textContent = 'Save Changes';
            this.classList.remove('edit-profile-btn');
            this.classList.add('save-profile-btn');
            
            // Add event listener for save button
            this.addEventListener('click', saveProfileChanges);
        });
    }
    
    // Save profile changes
    function saveProfileChanges() {
        // Get all inputs
        const inputs = document.querySelectorAll('.edit-input');
        
        // Replace inputs with text
        inputs.forEach(input => {
            const parent = input.parentElement;
            parent.textContent = input.value;
        });
        
        // Change button text and functionality
        this.textContent = 'Edit Profile';
        this.classList.remove('save-profile-btn');
        this.classList.add('edit-profile-btn');
        
        // Remove this event listener
        this.removeEventListener('click', saveProfileChanges);
        
        // Show success message
        alert('Profile updated successfully!');
    }
    
    // Add/remove skills
    const addSkillForm = document.querySelector('.add-skill-form');
    if (addSkillForm) {
        const addSkillBtn = addSkillForm.querySelector('button');
        const skillInput = document.getElementById('newSkill');
        
        addSkillBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const skillValue = skillInput.value.trim();
            if (skillValue) {
                // Create new skill tag
                const skillTag = document.createElement('span');
                skillTag.className = 'skill-tag';
                skillTag.innerHTML = `${skillValue} <button class="remove-skill-btn"><i class="fas fa-times"></i></button>`;
                
                // Add to skills container
                const skillsContainer = document.querySelector('.skills-container');
                skillsContainer.appendChild(skillTag);
                
                // Clear input
                skillInput.value = '';
                
                // Add event listener to remove button
                const removeBtn = skillTag.querySelector('.remove-skill-btn');
                removeBtn.addEventListener('click', function() {
                    skillTag.remove();
                });
            }
        });
    }
    
    // Add/remove interests
    const addInterestForm = document.querySelector('.add-interest-form');
    if (addInterestForm) {
        const addInterestBtn = addInterestForm.querySelector('button');
        const interestInput = document.getElementById('newInterest');
        
        addInterestBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const interestValue = interestInput.value.trim();
            if (interestValue) {
                // Create new interest item
                const interestItem = document.createElement('div');
                interestItem.className = 'interest-item';
                interestItem.innerHTML = `
                    <span class="interest-name">${interestValue}</span>
                    <button class="btn-icon"><i class="fas fa-times"></i></button>
                `;
                
                // Add to interests container
                const interestsContainer = document.querySelector('.interests-container');
                interestsContainer.appendChild(interestItem);
                
                // Clear input
                interestInput.value = '';
                
                // Add event listener to remove button
                const removeBtn = interestItem.querySelector('.btn-icon');
                removeBtn.addEventListener('click', function() {
                    interestItem.remove();
                });
            }
        });
    }
    
    // Initialize remove buttons for existing skills and interests
    const removeSkillBtns = document.querySelectorAll('.remove-skill-btn');
    removeSkillBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const skillTag = this.closest('.skill-tag');
            if (skillTag) {
                skillTag.remove();
            }
        });
    });
    
    const removeInterestBtns = document.querySelectorAll('.interest-item .btn-icon');
    removeInterestBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const interestItem = this.closest('.interest-item');
            if (interestItem) {
                interestItem.remove();
            }
        });
    });
    
    // Add experience button
    const addExperienceBtn = document.querySelector('.add-experience-btn');
    if (addExperienceBtn) {
        addExperienceBtn.addEventListener('click', function() {
            // Create a form to add new experience (modal or inline form)
            alert('Add experience functionality to be implemented');
        });
    }
    
    // Add activity button
    const addActivityBtn = document.querySelector('.add-activity-btn');
    if (addActivityBtn) {
        addActivityBtn.addEventListener('click', function() {
            // Create a form to add new activity (modal or inline form)
            alert('Add activity functionality to be implemented');
        });
    }
});