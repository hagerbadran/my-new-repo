class PDFGenerator {
  static async generateReportPDF(reportId) {
    // Get report data
    const response = await fetch(`/api/reports/${reportId}`);
    const report = await response.json();
    
    // Create PDF (using jsPDF)
    const doc = new jsPDF();
    
    // Add title
    doc.setFontSize(20);
    doc.text(report.title, 15, 20);
    
    // Add student info
    doc.setFontSize(12);
    doc.text(`Student: ${report.studentName}`, 15, 30);
    doc.text(`Major: ${report.major}`, 15, 35);
    
    // Add report content
    doc.setFontSize(10);
    const splitText = doc.splitTextToSize(report.content, 180);
    doc.text(splitText, 15, 45);
    
    // Save the PDF
    doc.save(`internship-report-${reportId}.pdf`);
  }
}