class NotificationSystem {
  static init() {
    this.notificationCenter = document.getElementById('notificationCenter');
    this.setupPolling();
    this.setupUI();
  }

  static setupPolling() {
    setInterval(async () => {
      const response = await fetch('/api/notifications');
      const notifications = await response.json();
      this.updateNotifications(notifications);
    }, 30000); // Poll every 30 seconds
  }

  static updateNotifications(notifications) {
    this.notificationCenter.innerHTML = notifications.map(notif => `
      <div class="notification-item ${notif.type}">
        <div class="notification-icon">
          ${this.getIcon(notif.type)}
        </div>
        <div class="notification-content">
          <p>${notif.message}</p>
          <small>${new Date(notif.timestamp).toLocaleTimeString()}</small>
        </div>
      </div>
    `).join('');
  }

  static getIcon(type) {
    const icons = {
      application: '<i class="fas fa-file-alt"></i>',
      report: '<i class="fas fa-clipboard-check"></i>',
      general: '<i class="fas fa-bell"></i>'
    };
    return icons[type] || icons.general;
  }
}