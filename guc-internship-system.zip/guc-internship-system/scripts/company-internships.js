// Company Internships Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInternship = document.getElementById('searchInternship');
    if (searchInternship) {
        searchInternship.addEventListener('input', function() {
            filterCompanyInternships();
        });
    }
    
    // Filter functionality
    const durationFilter = document.getElementById('durationFilter');
    const paymentFilter = document.getElementById('paymentFilter');
    
    if (durationFilter) {
        durationFilter.addEventListener('change', filterCompanyInternships);
    }
    
    if (paymentFilter) {
        paymentFilter.addEventListener('change', filterCompanyInternships);
    }
    
    // Filter company internships based on search and filter values
    function filterCompanyInternships() {
        const searchValue = searchInternship ? searchInternship.value.toLowerCase() : '';
        const durationValue = durationFilter ? durationFilter.value : '';
        const paymentValue = paymentFilter ? paymentFilter.value : '';
        
        const internshipItems = document.querySelectorAll('.internship-item');
        
        internshipItems.forEach(item => {
            const title = item.querySelector('h3').textContent.toLowerCase();
            
            // Get duration and payment info from meta spans
            const metaSpans = item.querySelectorAll('.internship-meta span');
            let duration = '';
            let payment = '';
            
            metaSpans.forEach(span => {
                const text = span.textContent.toLowerCase();
                if (text.includes('month')) {
                    duration = text;
                }
                if (text.includes('paid') || text.includes('unpaid')) {
                    payment = text;
                }
            });
            
            // Check if the item matches all filters
            const matchesSearch = searchValue === '' || title.includes(searchValue);
            
            const matchesDuration = durationValue === '' || 
                                   (durationValue === '1-2' && duration.includes('1') || duration.includes('2')) ||
                                   (durationValue === '3-4' && duration.includes('3') || duration.includes('4')) ||
                                   (durationValue === '5-6' && duration.includes('5') || duration.includes('6')) ||
                                   (durationValue === '6+' && parseInt(duration) >= 6);
            
            const matchesPayment = paymentValue === '' || 
                                  (paymentValue === 'paid' && payment.includes('paid') && !payment.includes('unpaid')) ||
                                  (paymentValue === 'unpaid' && payment.includes('unpaid'));
            
            // Show or hide the item based on filter matches
            if (matchesSearch && matchesDuration && matchesPayment) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    // Delete internship confirmation
    const deleteButtons = document.querySelectorAll('.danger-btn');
    deleteButtons.forEach(button => {
        if (button.textContent.trim() === 'Delete') {
            button.addEventListener('click', function(e) {
                const confirmed = confirm('Are you sure you want to delete this internship?');
                
                if (!confirmed) {
                    e.preventDefault();
                } else {
                    // Find the parent internship item and remove it
                    const internshipItem = this.closest('.internship-item');
                    if (internshipItem) {
                        internshipItem.remove();
                    }
                }
            });
        }
    });
});