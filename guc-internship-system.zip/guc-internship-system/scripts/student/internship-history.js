// Internship History Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInternship = document.getElementById('searchInternship');
    if (searchInternship) {
        searchInternship.addEventListener('input', function() {
            filterInternships();
        });
    }
    
    // Filter functionality
    const statusFilter = document.getElementById('statusFilter');
    const dateFilter = document.getElementById('dateFilter');
    
    if (statusFilter) {
        statusFilter.addEventListener('change', filterInternships);
    }
    
    if (dateFilter) {
        dateFilter.addEventListener('change', filterInternships);
    }
    
    // Filter internships based on search and filter values
    function filterInternships() {
        const searchValue = searchInternship ? searchInternship.value.toLowerCase() : '';
        const statusValue = statusFilter ? statusFilter.value.toLowerCase() : '';
        const dateValue = dateFilter ? dateFilter.value : '';
        
        const timelineItems = document.querySelectorAll('.timeline-item');
        
        timelineItems.forEach(item => {
            const internshipTitle = item.querySelector('.internship-title h3').textContent.toLowerCase();
            const companyName = item.querySelector('.internship-title p').textContent.toLowerCase();
            const statusBadge = item.querySelector('.status-badge').textContent.toLowerCase();
            const internshipDate = item.querySelector('.detail-item:first-child span').textContent;
            
            // Check if the item matches all filters
            const matchesSearch = searchValue === '' || 
                                 internshipTitle.includes(searchValue) || 
                                 companyName.includes(searchValue);
            
            const matchesStatus = statusValue === '' || statusBadge.includes(statusValue);
            
            const matchesDate = dateValue === '' || 
                               (dateValue === '2025' && internshipDate.includes('2025')) ||
                               (dateValue === '2024' && internshipDate.includes('2024')) ||
                               (dateValue === '2023' && internshipDate.includes('2023'));
            
            // Show or hide the item based on filter matches
            if (matchesSearch && matchesStatus && matchesDate) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
        
        // Update stats based on filtered items
        updateStats();
    }
    
    // Update stats based on visible internships
    function updateStats() {
        const visibleInternships = document.querySelectorAll('.timeline-item[style="display: flex;"]');
        const currentInternships = document.querySelectorAll('.timeline-item[style="display: flex;"].current');
        const completedInternships = document.querySelectorAll('.timeline-item[style="display: flex;"].completed');
        
        const totalStat = document.querySelector('.stat-card:nth-child(1) h3');
        const currentStat = document.querySelector('.stat-card:nth-child(2) h3');
        const completedStat = document.querySelector('.stat-card:nth-child(3) h3');
        
        if (totalStat) totalStat.textContent = visibleInternships.length;
        if (currentStat) currentStat.textContent = currentInternships.length;
        if (completedStat) completedStat.textContent = completedInternships.length;
    }
    
    // Initialize stats on page load
    updateStats();
});