/**
 * Student Report functionality
 */

document.addEventListener("DOMContentLoaded", () => {
    // Initialize form
    initializeForm();

    // Set up event listeners
    setupEventListeners();
});

/**
 * Initialize form elements and data
 */
function initializeForm() {
    // Set up word count trackers
    setupWordCountTrackers();
    
    // Set up rating display
    setupRatingDisplay();
}

/**
 * Set up word count trackers for textareas
 */
function setupWordCountTrackers() {
    const textareas = [
        { id: 'introduction', minWords: 300 },
        { id: 'tasks', minWords: 500 },
        { id: 'skills', minWords: 300 },
        { id: 'challenges', minWords: 300 },
        { id: 'conclusion', minWords: 300 }
    ];
    
    textareas.forEach(item => {
        const textarea = document.getElementById(item.id);
        const countElement = document.getElementById(`${item.id}-count`);
        
        if (textarea && countElement) {
            textarea.addEventListener('input', () => {
                const wordCount = countWords(textarea.value);
                countElement.textContent = wordCount;
                
                if (wordCount < item.minWords) {
                    countElement.classList.add('below-minimum');
                } else {
                    countElement.classList.remove('below-minimum');
                }
            });
        }
    });
}

/**
 * Count words in a string
 * @param {string} text - The text to count words in
 * @returns {number} - The word count
 */
function countWords(text) {
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
}

/**
 * Set up rating display
 */
function setupRatingDisplay() {
    const ratingInputs = document.querySelectorAll('.rating input');
    const ratingText = document.querySelector('.rating-text');
    
    if (ratingInputs.length > 0 && ratingText) {
        ratingInputs.forEach(input => {
            input.addEventListener('change', () => {
                const value = input.value;
                let text = '';
                
                switch (value) {
                    case '1':
                        text = 'Poor';
                        break;
                    case '2':
                        text = 'Fair';
                        break;
                    case '3':
                        text = 'Good';
                        break;
                    case '4':
                        text = 'Very Good';
                        break;
                    case '5':
                        text = 'Excellent';
                        break;
                    default:
                        text = 'Select a rating';
                }
                
                ratingText.textContent = text;
            });
        });
    }
}

/**
 * Set up event listeners
 */
function setupEventListeners() {
    // Form submission
    const reportForm = document.getElementById('report-form');
    if (reportForm) {
        reportForm.addEventListener('submit', handleFormSubmit);
    }
    
    // Save draft button
    const saveDraftBtn = document.getElementById('save-draft');
    if (saveDraftBtn) {
        saveDraftBtn.addEventListener('click', handleSaveDraft);
    }
    
    // Preview button
    const previewBtn = document.getElementById('preview-report');
    if (previewBtn) {
        previewBtn.addEventListener('click', handlePreview);
    }
    
    // Close preview button
    const closePreviewBtn = document.getElementById('close-preview');
    if (closePreviewBtn) {
        closePreviewBtn.addEventListener('click', () => {
            document.getElementById('preview-modal').classList.remove('show');
        });
    }
    
    // Submit from preview button
    const submitFromPreviewBtn = document.getElementById('submit-from-preview');
    if (submitFromPreviewBtn) {
        submitFromPreviewBtn.addEventListener('click', () => {
            document.getElementById('preview-modal').classList.remove('show');
            handleFormSubmit(new Event('submit'));
        });
    }
    
    // Success modal buttons
    const goToDashboardBtn = document.getElementById('go-to-dashboard');
    if (goToDashboardBtn) {
        goToDashboardBtn.addEventListener('click', () => {
            window.location.href = 'dashboard.html';
        });
    }
    
    const viewReportsBtn = document.getElementById('view-reports');
    if (viewReportsBtn) {
        viewReportsBtn.addEventListener('click', () => {
            window.location.href = 'internship-history.html';
        });
    }
    
    // Close modal buttons
    const closeModalBtns = document.querySelectorAll('.close-modal');
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.modal');
            if (modal) {
                modal.classList.remove('show');
            }
        });
    });
}

/**
 * Handle form submission
 * @param {Event} e - The submit event
 */
function handleFormSubmit(e) {
    e.preventDefault();
    
    // Validate form
    if (!validateForm()) {
        return;
    }
    
    // In a real application, this would send the form data to the server
    // For now, we'll just show a success message
    
    // Show success modal
    document.getElementById('success-modal').classList.add('show');
}

/**
 * Handle save draft
 */
function handleSaveDraft() {
    // In a real application, this would save the form data to the server as a draft
    // For now, we'll just show a notification
    
    showNotification('Report saved as draft', 'success');
}

/**
 * Handle preview
 */
function handlePreview() {
    // Generate preview HTML
    const previewHTML = generatePreviewHTML();
    
    // Insert preview HTML
    const previewContainer = document.getElementById('report-preview');
    if (previewContainer) {
        previewContainer.innerHTML = previewHTML;
    }
    
    // Show preview modal
    document.getElementById('preview-modal').classList.add('show');
}

/**
 * Generate preview HTML
 * @returns {string} - The preview HTML
 */
function generatePreviewHTML() {
    const title = document.getElementById('report-title').value || 'Untitled Report';
    const period = document.getElementById('internship-period').value;
    const supervisor = document.getElementById('supervisor-name').value;
    const introduction = document.getElementById('introduction').value;
    const tasks = document.getElementById('tasks').value;
    const skills = document.getElementById('skills').value;
    const challenges = document.getElementById('challenges').value;
    const conclusion = document.getElementById('conclusion').value;
    
    // Get selected courses
    const courseCheckboxes = document.querySelectorAll('input[name="courses[]"]:checked');
    const courses = Array.from(courseCheckboxes).map(checkbox => checkbox.value);
    
    // Get rating
    const ratingInput = document.querySelector('input[name="rating"]:checked');
    const rating = ratingInput ? ratingInput.value : '';
    
    // Get recommendation
    const recommendInput = document.querySelector('input[name="recommend"]:checked');
    const recommend = recommendInput ? recommendInput.value : '';
    
    // Get company feedback
    const companyFeedback = document.getElementById('company-feedback').value;
    
    // Generate HTML
    let html = `
        <h1>${title}</h1>
        
        <div class="meta-info">
            <div class="meta-item">
                <span class="meta-label">Internship Period</span>
                <span class="meta-value">${period}</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Supervisor</span>
                <span class="meta-value">${supervisor}</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Company</span>
                <span class="meta-value">Tech Solutions Inc.</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Position</span>
                <span class="meta-value">Frontend Developer Intern</span>
            </div>
        </div>
        
        <h2>Introduction</h2>
        <p>${introduction.replace(/\n/g, '<br>')}</p>
        
        <h2>Tasks and Responsibilities</h2>
        <p>${tasks.replace(/\n/g, '<br>')}</p>
        
        <h2>Skills Developed</h2>
        <p>${skills.replace(/\n/g, '<br>')}</p>
        
        <h2>Challenges and Solutions</h2>
        <p>${challenges.replace(/\n/g, '<br>')}</p>
        
        <h2>Conclusion</h2>
        <p>${conclusion.replace(/\n/g, '<br>')}</p>
    `;
    
    if (courses.length > 0) {
        html += `
            <h2>Relevant Courses</h2>
            <div class="course-tags">
                ${courses.map(course => `<span class="course-tag">${course}</span>`).join('')}
            </div>
        `;
    }
    
    if (rating || companyFeedback || recommend) {
        html += `
            <div class="company-evaluation">
                <h2>Company Evaluation</h2>
        `;
        
        if (rating) {
            html += `
                <h3>Overall Experience</h3>
                <div class="rating-display">${'★'.repeat(parseInt(rating))}</div>
            `;
        }
        
        if (companyFeedback) {
            html += `
                <h3>Feedback</h3>
                <p>${companyFeedback.replace(/\n/g, '<br>')}</p>
            `;
        }
        
        if (recommend) {
            html += `
                <h3>Recommendation</h3>
                <p>Would recommend to other students: <strong>${recommend === 'yes' ? 'Yes' : 'No'}</strong></p>
            `;
        }
        
        html += `</div>`;
    }
    
    return html;
}

/**
 * Validate form
 * @returns {boolean} - Whether the form is valid
 */
function validateForm() {
    // Check required fields
    const requiredFields = [
        'report-title',
        'supervisor-name',
        'supervisor-email',
        'introduction',
        'tasks',
        'skills',
        'challenges',
        'conclusion',
        'company-feedback'
    ];
    
    let isValid = true;
    
    requiredFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field && !field.value.trim()) {
            field.classList.add('error');
            isValid = false;
        } else if (field) {
            field.classList.remove('error');
        }
    });
    
    // Check word counts
    const textareas = [
        { id: 'introduction', minWords: 300 },
        { id: 'tasks', minWords: 500 },
        { id: 'skills', minWords: 300 },
        { id: 'challenges', minWords: 300 },
        { id: 'conclusion', minWords: 300 }
    ];
    
    textareas.forEach(item => {
        const textarea = document.getElementById(item.id);
        if (textarea) {
            const wordCount = countWords(textarea.value);
            if (wordCount < item.minWords) {
                textarea.classList.add('error');
                isValid = false;
                
                showNotification(`${item.id.charAt(0).toUpperCase() + item.id.slice(1)} must be at least ${item.minWords} words`, 'error');
            }
        }
    });
    
    // Check rating
    const ratingSelected = document.querySelector('input[name="rating"]:checked');
    if (!ratingSelected) {
        document.querySelector('.rating-container').classList.add('error');
        isValid = false;
    } else {
        document.querySelector('.rating-container').classList.remove('error');
    }
    
    // Check recommendation
    const recommendSelected = document.querySelector('input[name="recommend"]:checked');
    if (!recommendSelected) {
        document.querySelector('.radio-group').classList.add('error');
        isValid = false;
    } else {
        document.querySelector('.radio-group').classList.remove('error');
    }
    
    if (!isValid) {
        showNotification('Please fill in all required fields correctly', 'error');
    }
    
    return isValid;
}

/**
 * Show notification
 * @param {string} message - The notification message
 * @param {string} type - The notification type
 */
function showNotification(message, type) {
    // Check if notification container exists
    let notificationContainer = document.querySelector('.notification-container');
    
    // If not, create it
    if (!notificationContainer) {
        notificationContainer = document.createElement('div');
        notificationContainer.className = 'notification-container';
        document.body.appendChild(notificationContainer);
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <p>${message}</p>
        </div>
        <button class="notification-close">&times;</button>
    `;
    
    // Add to container
    notificationContainer.appendChild(notification);
    
    // Add event listener to close button
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.remove();
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}