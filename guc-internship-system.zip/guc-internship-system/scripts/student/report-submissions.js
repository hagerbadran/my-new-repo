class ReportSubmitter {
  constructor() {
    this.initForm();
    this.loadCourses();
  }

  async loadCourses() {
    const major = JSON.parse(localStorage.getItem('studentProfile')).major;
    const response = await fetch(`/api/courses?major=${major}`);
    const courses = await response.json();
    
    const container = document.querySelector('.courses-select');
    container.innerHTML = courses.map(course => `
      <div class="course-checkbox">
        <input type="checkbox" id="course${course.code}" value="${course.code}">
        <label for="course${course.code}">${course.name} (${course.code})</label>
      </div>
    `).join('');
  }

  initForm() {
    document.getElementById('reportForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const formData = new FormData();
      formData.append('title', document.getElementById('reportTitle').value);
      formData.append('content', document.getElementById('reportContent').value);
      
      const selectedCourses = Array.from(
        document.querySelectorAll('.course-checkbox input:checked')
      ).map(el => el.value);
      
      formData.append('courses', JSON.stringify(selectedCourses));
      
      const files = document.getElementById('reportDocuments').files;
      for (let i = 0; i < files.length; i++) {
        formData.append('documents', files[i]);
      }
      
      try {
        const response = await fetch('/api/reports', {
          method: 'POST',
          body: formData
        });
        
        if (response.ok) {
          window.location.href = 'report-status.html';
        }
      } catch (error) {
        console.error('Report submission failed:', error);
      }
    });
  }
}