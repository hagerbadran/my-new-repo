class StatusTracker {
  constructor() {
    this.applicationId = new URLSearchParams(window.location.search).get('id');
    this.loadStatus();
    this.initEventHandlers();
  }

  async loadStatus() {
    const response = await fetch(`/api/applications/${this.applicationId}/status`);
    const data = await response.json();
    
    const statusBadge = document.getElementById('statusBadge');
    statusBadge.textContent = data.status;
    statusBadge.className = `status-badge ${data.status.toLowerCase()}`;
    
    // Update timeline based on status
    const timelineItems = document.querySelectorAll('.timeline-item');
    timelineItems.forEach((item, index) => {
      if (index <= this.getStatusIndex(data.status)) {
        item.classList.add('active');
      }
    });
  }

  getStatusIndex(status) {
    const statusOrder = ['submitted', 'reviewed', 'accepted/rejected'];
    return statusOrder.indexOf(status.toLowerCase());
  }
}