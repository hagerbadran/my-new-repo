// scripts/student/internship-browser.js
class InternshipBrowser {
  static async loadInternships(filters = {}) {
    const response = await fetch('/api/internships');
    const data = await response.json();
    
    const container = document.getElementById('internshipList');
    container.innerHTML = data.map(internship => `
      <div class="internship-card">
        <h3>${internship.title}</h3>
        <p>${internship.company}</p>
        <span>${internship.duration} months</span>
        <button class="btn apply-btn" data-id="${internship.id}">Apply</button>
      </div>
    `).join('');
  }
}