// Application Details Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Status update functionality
    const applicationStatus = document.getElementById('applicationStatus');
    const updateStatusBtn = document.getElementById('updateStatusBtn');
    const currentStatusBadge = document.querySelector('.current-status .status-badge');
    const statusDate = document.querySelector('.status-date');
    
    if (updateStatusBtn) {
        updateStatusBtn.addEventListener('click', function() {
            const newStatus = applicationStatus.value;
            const confirmed = confirm(`Are you sure you want to update the status to "${newStatus}"?`);
            
            if (confirmed) {
                // Remove all status classes
                currentStatusBadge.classList.remove('pending', 'finalized', 'accepted', 'rejected', 'current', 'completed');
                
                // Add the new status class
                currentStatusBadge.classList.add(newStatus);
                
                // Update the text content
                currentStatusBadge.textContent = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
                
                // Update the date
                const today = new Date();
                const formattedDate = today.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
                statusDate.textContent = `Updated on: ${formattedDate}`;
                
                // Show success message
                alert(`Application status has been updated to "${newStatus}".`);
                
                // Update action buttons based on new status
                updateActionButtons(newStatus);
            }
        });
    }
    
    // Action buttons functionality
    const rejectBtn = document.getElementById('rejectBtn');
    const finalizeBtn = document.getElementById('finalizeBtn');
    const acceptBtn = document.getElementById('acceptBtn');
    
    if (rejectBtn) {
        rejectBtn.addEventListener('click', function() {
            const confirmed = confirm('Are you sure you want to reject this application?');
            
            if (confirmed) {
                // Set status to rejected
                applicationStatus.value = 'rejected';
                
                // Trigger status update
                updateStatusBtn.click();
            }
        });
    }
    
    if (finalizeBtn) {
        finalizeBtn.addEventListener('click', function() {
            const confirmed = confirm('Are you sure you want to mark this application as finalized?');
            
            if (confirmed) {
                // Set status to finalized
                applicationStatus.value = 'finalized';
                
                // Trigger status update
                updateStatusBtn.click();
            }
        });
    }
    
    if (acceptBtn) {
        acceptBtn.addEventListener('click', function() {
            const confirmed = confirm('Are you sure you want to accept this application?');
            
            if (confirmed) {
                // Set status to accepted
                applicationStatus.value = 'accepted';
                
                // Trigger status update
                updateStatusBtn.click();
            }
        });
    }
    
    // Function to update action buttons based on status
    function updateActionButtons(status) {
        if (rejectBtn && finalizeBtn && acceptBtn) {
            switch (status) {
                case 'pending':
                    rejectBtn.style.display = 'block';
                    finalizeBtn.style.display = 'block';
                    acceptBtn.style.display = 'block';
                    break;
                case 'finalized':
                    rejectBtn.style.display = 'block';
                    finalizeBtn.style.display = 'none';
                    acceptBtn.style.display = 'block';
                    break;
                case 'accepted':
                    rejectBtn.style.display = 'none';
                    finalizeBtn.style.display = 'none';
                    acceptBtn.textContent = 'Mark as Current Intern';
                    acceptBtn.addEventListener('click', function() {
                        applicationStatus.value = 'current';
                        updateStatusBtn.click();
                    });
                    break;
                case 'rejected':
                    rejectBtn.style.display = 'none';
                    finalizeBtn.style.display = 'none';
                    acceptBtn.style.display = 'none';
                    break;
                case 'current':
                    rejectBtn.style.display = 'none';
                    finalizeBtn.style.display = 'none';
                    acceptBtn.textContent = 'Mark as Completed';
                    acceptBtn.addEventListener('click', function() {
                        applicationStatus.value = 'completed';
                        updateStatusBtn.click();
                    });
                    break;
                case 'completed':
                    rejectBtn.style.display = 'none';
                    finalizeBtn.style.display = 'none';
                    acceptBtn.style.display = 'none';
                    break;
            }
        }
    }
    
    // Download application as PDF
    const downloadApplicationBtn = document.getElementById('downloadApplicationBtn');
    
    if (downloadApplicationBtn) {
        downloadApplicationBtn.addEventListener('click', function() {
            alert('Downloading application as PDF...');
            // In a real implementation, this would trigger a PDF generation and download
        });
    }
    
    // Document view functionality
    const viewButtons = document.querySelectorAll('.document-actions .btn-icon:first-child');
    
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const documentName = this.closest('.document-item').querySelector('span').textContent;
            alert(`Viewing ${documentName}...`);
            // In a real implementation, this would open a document viewer
        });
    });
    
    // Document download functionality
    const downloadButtons = document.querySelectorAll('.download-btn');
    
    downloadButtons.forEach(button => {
        button.addEventListener('click', function() {
            const documentName = this.closest('.document-item').querySelector('span').textContent;
            alert(`Downloading ${documentName}...`);
            // In a real implementation, this would trigger a document download
        });
    });
});