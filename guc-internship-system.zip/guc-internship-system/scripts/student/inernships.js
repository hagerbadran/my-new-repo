document.addEventListener('DOMContentLoaded', function() {
    // Mobile sidebar toggle
    const mobileMenuToggle = document.createElement('button');
    mobileMenuToggle.className = 'mobile-menu-toggle btn primary-btn';
    mobileMenuToggle.innerHTML = '<i class="fas fa-bars"></i> Menu';
    
    const contentHeader = document.querySelector('.content-header');
    if (contentHeader && window.innerWidth < 768) {
        contentHeader.insertBefore(mobileMenuToggle, contentHeader.firstChild);
        
        const sidebar = document.querySelector('.sidebar');
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // Application Modal
    const modal = document.getElementById('applicationModal');
    const applyButtons = document.querySelectorAll('.apply-btn');
    const closeModalButtons = document.querySelectorAll('.close-modal');
    
    // Show modal when apply button is clicked
    applyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const jobTitle = this.closest('.internship-card').querySelector('h4').textContent;
            document.getElementById('modalJobTitle').textContent = jobTitle;
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        });
    });
    
    // Close modal
    closeModalButtons.forEach(button => {
        button.addEventListener('click', function() {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    });
    
    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });
    
    // File upload display
    const resumeInput = document.getElementById('resume');
    if (resumeInput) {
        resumeInput.addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
            document.getElementById('fileName').textContent = fileName;
        });
    }
    
    // Form submission
    const applicationForm = document.getElementById('applicationForm');
    if (applicationForm) {
        applicationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validate form
            if (!resumeInput.files[0]) {
                alert('Please upload your resume');
                return;
            }
            
            // Simulate form submission
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
            submitBtn.disabled = true;
            
            // Simulate API call
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                
                // Show success message
                alert('Application submitted successfully!');
                
                // Close modal
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
                
                // Reset form
                this.reset();
                document.getElementById('fileName').textContent = 'No file chosen';
            }, 1500);
        });
    }
    
    // Save internship
    const saveButtons = document.querySelectorAll('.btn-secondary:not(.close-modal)');
    saveButtons.forEach(button => {
        button.addEventListener('click', function() {
            const card = this.closest('.internship-card');
            const jobTitle = card.querySelector('h4').textContent;
            
            this.innerHTML = this.innerHTML.includes('Saved') 
                ? '<i class="fas fa-bookmark"></i> Save' 
                : '<i class="fas fa-check"></i> Saved';
            
            console.log(this.innerHTML.includes('Saved') 
                ? `Saved: ${jobTitle}` 
                : `Removed: ${jobTitle}`);
        });
    });
    
    // Filter functionality
    const filterBtn = document.querySelector('.filter-options .btn');
    if (filterBtn) {
        filterBtn.addEventListener('click', function(e) {
            e.preventDefault();
            // TODO: Implement filter functionality
            console.log('Filters applied');
        });
    }
    
    // Responsive adjustments
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 768 && document.querySelector('.mobile-menu-toggle')) {
            document.querySelector('.mobile-menu-toggle').remove();
            document.querySelector('.sidebar').classList.remove('active');
        }
    });
});