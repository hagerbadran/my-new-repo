// Dummy data for the system
const dummyData = {
    users: {
        student: {
            email: "student@guc.edu.eg",
            password: "student123",
            name: "Ahmed Mohamed",
            major: "BI",
            semester: 6
        },
        company: {
            email: "company@example.com",
            password: "company123",
            name: "Tech Solutions Inc."
        },
        scad: {
            email: "scad@guc.edu.eg",
            password: "scad123"
        }
    },
    internships: [
        {
            id: 1,
            title: "Software Developer Intern",
            company: "Tech Solutions Inc.",
            duration: "3 months",
            paid: true,
            salary: "5000 EGP/month",
            skills: ["JavaScript", "React", "Node.js"],
            description: "Work on web applications using modern technologies."
        }
        // Add more internships
    ]
};

export default dummyData;