// Internship Details Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Apply button functionality
    const applyBtn = document.getElementById('applyBtn');
    const applicationForm = document.getElementById('applicationForm');
    const cancelApplication = document.getElementById('cancelApplication');
    
    if (applyBtn && applicationForm) {
        applyBtn.addEventListener('click', function() {
            applicationForm.style.display = 'block';
            applyBtn.style.display = 'none';
            
            // Scroll to application form
            applicationForm.scrollIntoView({ behavior: 'smooth' });
        });
    }
    
    if (cancelApplication) {
        cancelApplication.addEventListener('click', function() {
            applicationForm.style.display = 'none';
            applyBtn.style.display = 'block';
        });
    }
    
    // Application form submission
    const internshipApplicationForm = document.getElementById('internshipApplicationForm');
    if (internshipApplicationForm) {
        internshipApplicationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const coverLetter = document.getElementById('coverLetter').value;
            const resume = document.getElementById('resume').files[0];
            
            // Simple validation
            if (!coverLetter || !resume) {
                alert('Please fill in all required fields');
                return;
            }
            
            // Show success message and redirect
            alert('Application submitted successfully!');
            window.location.href = 'student-applications.html';
        });
    }
});