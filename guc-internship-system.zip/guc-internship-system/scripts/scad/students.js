// SCAD Students Management Scripts
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchStudent = document.getElementById('searchStudent');
    if (searchStudent) {
        searchStudent.addEventListener('input', function() {
            filterStudents();
        });
    }
    
    // Filter functionality
    const majorFilter = document.getElementById('majorFilter');
    const statusFilter = document.getElementById('statusFilter');
    const semesterFilter = document.getElementById('semesterFilter');
    
    if (majorFilter) {
        majorFilter.addEventListener('change', filterStudents);
    }
    
    if (statusFilter) {
        statusFilter.addEventListener('change', filterStudents);
    }
    
    if (semesterFilter) {
        semesterFilter.addEventListener('change', filterStudents);
    }
    
    // Filter students based on search and filter values
    function filterStudents() {
        const searchValue = searchStudent ? searchStudent.value.toLowerCase() : '';
        const majorValue = majorFilter ? majorFilter.value.toLowerCase() : '';
        const statusValue = statusFilter ? statusFilter.value.toLowerCase() : '';
        const semesterValue = semesterFilter ? semesterFilter.value.toLowerCase() : '';
        
        const tableRows = document.querySelectorAll('.students-table tbody tr');
        
        tableRows.forEach(row => {
            const studentId = row.querySelector('td:first-child').textContent.toLowerCase();
            const studentName = row.querySelector('.student-name span').textContent.toLowerCase();
            const major = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
            const semester = row.querySelector('td:nth-child(4)').textContent.toLowerCase();
            const status = row.querySelector('.status-badge').textContent.toLowerCase();
            
            // Check if the row matches all filters
            const matchesSearch = searchValue === '' || 
                                 studentId.includes(searchValue) || 
                                 studentName.includes(searchValue);
            
            const matchesMajor = majorValue === '' || 
                               (majorValue === 'cs' && major.includes('computer science')) ||
                               (majorValue === 'ce' && major.includes('computer engineering')) ||
                               (majorValue === 'met' && major.includes('media engineering')) ||
                               (majorValue === 'bi' && major.includes('business informatics')) ||
                               (majorValue === 'dmet' && major.includes('digital media'));
            
            const matchesStatus = statusValue === '' || 
                                (statusValue === 'none' && status === '') ||
                                (statusValue === 'applied' && status.includes('applied')) ||
                                (statusValue === 'current' && status.includes('current')) ||
                                (statusValue === 'completed' && status.includes('completed'));
            
            const matchesSemester = semesterValue === '' || 
                                  (semesterValue === '1-2' && (semester === '1' || semester === '2')) ||
                                  (semesterValue === '3-4' && (semester === '3' || semester === '4')) ||
                                  (semesterValue === '5-6' && (semester === '5' || semester === '6')) ||
                                  (semesterValue === '7-8' && (semester === '7' || semester === '8')) ||
                                  (semesterValue === '9-10' && (semester === '9' || semester === '10'));
            
            // Show or hide the row based on filter matches
            if (matchesSearch && matchesMajor && matchesStatus && matchesSemester) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
        
        // Update stats based on filtered students
        updateStats();
    }
    
    // Update stats based on visible students
    function updateStats() {
        const visibleStudents = document.querySelectorAll('.students-table tbody tr:not([style="display: none;"])');
        const currentInterns = document.querySelectorAll('.students-table tbody tr:not([style="display: none;"]) .status-badge.current');
        const completedInterns = document.querySelectorAll('.students-table tbody tr:not([style="display: none;"]) .status-badge.completed');
        const reportSubmissions = document.querySelectorAll('.students-table tbody tr:not([style="display: none;"]) .report-badge:not(.none)');
        
        const totalStat = document.querySelector('.stat-card:nth-child(1) h3');
        const currentStat = document.querySelector('.stat-card:nth-child(2) h3');
        const completedStat = document.querySelector('.stat-card:nth-child(3) h3');
        const reportStat = document.querySelector('.stat-card:nth-child(4) h3');
        
        if (totalStat) totalStat.textContent = visibleStudents.length;
        if (currentStat) currentStat.textContent = currentInterns.length;
        if (completedStat) completedStat.textContent = completedInterns.length;
        if (reportStat) reportStat.textContent = reportSubmissions.length;
    }
    
    // Email functionality
    const emailButtons = document.querySelectorAll('.table-actions .btn-icon:last-child');
    
    emailButtons.forEach(button => {
        button.addEventListener('click', function() {
            const studentName = this.closest('tr').querySelector('.student-name span').textContent;
            alert(`Sending email to ${studentName}...`);
            // In a real implementation, this would open an email composition interface
        });
    });
    
    // Pagination functionality
    const paginationButtons = document.querySelectorAll('.pagination-btn');
    
    paginationButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            paginationButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // In a real implementation, this would load the corresponding page of students
            if (!this.textContent.includes('Next')) {
                alert(`Loading page ${this.textContent}...`);
            } else {
                alert('Loading next page...');
            }
        });
    });
    
    // Initialize stats on page load
    updateStats();
});
