class AdminDashboard {
  static init() {
    this.loadPendingCompanies();
    this.initEventListeners();
  }

  static loadPendingCompanies() {
    CompanyService.getPending()
      .then(companies => {
        const table = document.getElementById('pendingCompanies');
        companies.forEach(company => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${company.name}</td>
            <td>${company.industry}</td>
            <td>
              <button class="btn approve-btn" data-id="${company.id}">Approve</button>
              <button class="btn reject-btn" data-id="${company.id}">Reject</button>
            </td>
          `;
          table.appendChild(row);
        });
      });
  }
}