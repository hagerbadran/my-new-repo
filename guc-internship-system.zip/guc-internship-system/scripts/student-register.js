document.getElementById('studentRegisterForm').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent form submission

    // Get form values
    const fullName = document.getElementById('fullName').value;
    const gucId = document.getElementById('gucId').value;
    const major = document.getElementById('major').value;
    const semester = document.getElementById('semester').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Validate form inputs
    if (!fullName || !gucId || !major || !semester || !email || !password) {
        alert('Please fill in all required fields.');
        return;
    }

    // Save user data to localStorage (or send to a backend API if available)
    const user = {
        fullName,
        gucId,
        major,
        semester,
        email,
        password,
    };

    // Check if email already exists
    const existingUsers = JSON.parse(localStorage.getItem('users')) || [];
    const userExists = existingUsers.some((u) => u.email === email);

    if (userExists) {
        alert('An account with this email already exists. Please login.');
        return;
    }

    // Add new user to localStorage
    existingUsers.push(user);
    localStorage.setItem('users', JSON.stringify(existingUsers));

    alert('Account created successfully! Redirecting to login page...');
    window.location.href = 'login.html'; // Redirect to login page
});