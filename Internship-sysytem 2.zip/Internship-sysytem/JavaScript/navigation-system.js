/**
 * Central Navigation System for SCAD Internship Management System
 * This script handles navigation between all pages in the system
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all navigation links
    initializeNavLinks();
    
    // Highlight current page in navigation
    highlightCurrentPage();
});

/**
 * Initialize all navigation links in the page
 */
function initializeNavLinks() {
    // Fix all relative links to use the correct path
    document.querySelectorAll('a').forEach(link => {
        const href = link.getAttribute('href');
        
        // Skip if no href, external link, or already has correct path
        if (!href || href.startsWith('http') || href.startsWith('#') || href.startsWith('/')) {
            return;
        }
        
        // Determine the correct path based on current location
        const currentPath = window.location.pathname;
        const userType = getUserTypeFromPath(currentPath);
        
        if (userType) {
            // If the link is to a page in the same user area, keep it relative
            if (href.startsWith(`${userType}/`) || href.startsWith(`${userType}.html`)) {
                return;
            }
            
            // If the link is to a different user area, make it absolute
            if (href.includes('/')) {
                link.setAttribute('href', `/${href}`);
            } else {
                // If it's just a filename, assume it's in the same directory
                const directory = currentPath.substring(0, currentPath.lastIndexOf('/'));
                link.setAttribute('href', `${directory}/${href}`);
            }
        }
    });
}

/**
 * Highlight the current page in the navigation menu
 */
function highlightCurrentPage() {
    const currentPage = window.location.pathname;
    
    // Remove 'active' class from all navigation links
    document.querySelectorAll('nav ul li a').forEach(link => {
        link.classList.remove('active');
    });
    
    // Add 'active' class to current page link
    document.querySelectorAll('nav ul li a').forEach(link => {
        const href = link.getAttribute('href');
        if (href && (currentPage.endsWith(href) || currentPage === href)) {
            link.classList.add('active');
        }
    });
}

/**
 * Get the user type from the current path
 * @param {string} path - The current URL path
 * @returns {string|null} - The user type or null if not found
 */
function getUserTypeFromPath(path) {
    if (path.includes('/student/')) {
        return 'student';
    } else if (path.includes('/company/')) {
        return 'company';
    } else if (path.includes('/scad/')) {
        return 'scad';
    }
    return null;
}

/**
 * Navigate to a specific page
 * @param {string} page - The page to navigate to
 * @param {Object} params - URL parameters to include
 */
function navigateTo(page, params = {}) {
    // Build the URL with parameters
    let url = page;
    const queryParams = new URLSearchParams();
    
    for (const key in params) {
        if (params.hasOwnProperty(key)) {
            queryParams.append(key, params[key]);
        }
    }
    
    const queryString = queryParams.toString();
    if (queryString) {
        url += `?${queryString}`;
    }
    
    // Navigate to the URL
    window.location.href = url;
}