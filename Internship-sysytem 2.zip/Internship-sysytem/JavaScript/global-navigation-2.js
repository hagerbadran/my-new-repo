/**
 * Global Navigation System for SCAD Internship Management System
 * This script handles navigation between pages and user type switching
 */

// Store current user type
let currentUserType = localStorage.getItem('userType') || 'student';

// Page mappings for different user types
const pageMap = {
    student: {
        dashboard: '/student/student-dashboard.html',
        internships: '/student/internship-listings.html',
        applications: '/student/student-applications.html',
        myInternships: '/student/student-internships.html',
        reports: '/student/student-reports.html',
        profile: '/student/student-profile.html'
    },
    company: {
        dashboard: '/company/company-dashboard.html',
        jobPosts: '/company/company-job-posts.html',
        applications: '/company/company-applications.html',
        interns: '/company/company-interns.html',
        reports: '/company/company-reports.html',
        profile: '/company/company-profile.html'
    },
    scad: {
        dashboard: '/scad/scad-dashboard.html',
        companies: '/scad/scad-companies.html',
        internships: '/scad/scad-internships.html',
        reports: '/scad/scad-reports.html',
        statistics: '/scad/scad-statistics.html',
        assessments: '/scad/online-assessments.html',
        workshops: '/scad/workshop-management.html'
    }
};

/**
 * Navigate to a specific page based on current user type
 * @param {string} pageType - The type of page to navigate to
 * @param {string} id - Optional ID parameter for detail pages
 */
function navigateTo(pageType, id = null) {
    if (!pageMap[currentUserType] || !pageMap[currentUserType][pageType]) {
        console.error(`Invalid page type: ${pageType} for user type: ${currentUserType}`);
        return;
    }
    
    let url = pageMap[currentUserType][pageType];
    
    // Add ID parameter if provided
    if (id) {
        url += `?id=${id}`;
    }
    
    window.location.href = url;
}

/**
 * Switch user type and redirect to appropriate dashboard
 * @param {string} userType - The user type to switch to
 */
function switchUserType(userType) {
    if (!['student', 'company', 'scad'].includes(userType)) {
        console.error(`Invalid user type: ${userType}`);
        return;
    }
    
    // Store new user type
    localStorage.setItem('userType', userType);
    currentUserType = userType;
    
    // Redirect to appropriate dashboard
    navigateTo('dashboard');
}

/**
 * Highlight the current page in the navigation menu
 */
function highlightCurrentPage() {
    const currentPage = window.location.pathname.split('/').pop();
    
    // Remove 'active' class from all navigation links
    document.querySelectorAll('nav ul li a').forEach(link => {
        link.classList.remove('active');
    });
    
    // Add 'active' class to current page link
    if (currentPage) {
        // Try to find the matching link
        const activeLink = document.querySelector(`nav ul li a[href$="${currentPage}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        } else {
            // Handle special cases or partial matches
            document.querySelectorAll('nav ul li a').forEach(link => {
                const href = link.getAttribute('href');
                if (href && currentPage.includes(href.split('/').pop().split('.')[0])) {
                    link.classList.add('active');
                }
            });
        }
    }
}

/**
 * Set up navigation buttons with click handlers
 */
function setupNavigationButtons() {
    // Generic navigation buttons
    document.querySelectorAll('[data-navigate]').forEach(button => {
        button.addEventListener('click', function() {
            const pageType = this.getAttribute('data-navigate');
            const id = this.getAttribute('data-id');
            navigateTo(pageType, id);
        });
    });
    
    // User type switcher
    document.querySelectorAll('[data-switch-user]').forEach(button => {
        button.addEventListener('click', function() {
            const userType = this.getAttribute('data-switch-user');
            switchUserType(userType);
        });
    });
}

/**
 * Initialize user menu dropdown functionality
 */
function initializeUserMenu() {
    const userInfo = document.querySelector('.user-info');
    if (userInfo) {
        userInfo.addEventListener('click', function() {
            const dropdownMenu = this.nextElementSibling;
            if (dropdownMenu && dropdownMenu.classList.contains('dropdown-menu')) {
                dropdownMenu.classList.toggle('active');
            }
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.user-menu')) {
                const dropdownMenus = document.querySelectorAll('.dropdown-menu');
                dropdownMenus.forEach(menu => menu.classList.remove('active'));
            }
        });
    }
}

/**
 * Initialize navigation elements on the page
 */
function initNavigation() {
    // Highlight current page in navigation
    highlightCurrentPage();
    
    // Set up navigation buttons
    setupNavigationButtons();
    
    // Initialize user menu
    initializeUserMenu();
}

// Initialize navigation when the DOM is loaded
document.addEventListener('DOMContentLoaded', initNavigation);