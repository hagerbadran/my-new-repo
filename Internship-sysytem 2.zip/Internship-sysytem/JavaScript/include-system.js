/**
 * Include System for SCAD Internship Management System
 * This script handles the inclusion of HTML components like headers and footers
 */

/**
 * Includes HTML content from an external file into a specified element
 * @param {string} elementId - The ID of the element to include content into
 * @param {string} filePath - The path to the HTML file to include
 * @returns {Promise} - A promise that resolves when the content is included
 */
async function includeHTML(elementId, filePath) {
    const element = document.getElementById(elementId);
    if (!element) {
        console.error(`Element with ID "${elementId}" not found.`);
        return;
    }

    try {
        const response = await fetch(filePath);
        if (!response.ok) {
            throw new Error(`Failed to fetch ${filePath}: ${response.status} ${response.statusText}`);
        }

        const html = await response.text();
        element.innerHTML = html;

        // Execute any scripts in the included HTML
        const scripts = element.querySelectorAll('script');
        scripts.forEach(script => {
            const newScript = document.createElement('script');
            if (script.src) {
                newScript.src = script.src;
            } else {
                newScript.textContent = script.textContent;
            }
            document.body.appendChild(newScript);
        });

        return element;
    } catch (error) {
        console.error('Error loading include:', error);
        element.innerHTML = `<div class="error-message">Failed to load content: ${error.message}</div>`;
    }
}

/**
 * Determines the user type based on the current URL path
 * @returns {string} - The user type: 'student', 'company', or 'scad'
 */
function determineUserType() {
    const path = window.location.pathname;
    
    if (path.includes('/student/')) {
        return 'student';
    } else if (path.includes('/company/')) {
        return 'company';
    } else if (path.includes('/scad/')) {
        return 'scad';
    }
    
    // Default to the stored user type or 'student' if none is found
    return localStorage.getItem('userType') || 'student';
}

/**
 * Initializes the include system by loading the appropriate header and footer
 */
async function initializeIncludes() {
    const userType = determineUserType();
    
    // Store the current user type
    localStorage.setItem('userType', userType);
    
    // Include the appropriate header based on user type
    await includeHTML('header-container', `/includes/${userType}-header.html`);
    
    // Include the common footer
    await includeHTML('footer-container', '/includes/footer.html');
    
    // Initialize navigation after includes are loaded
    let initNavigation; // Declare initNavigation
    if (typeof window.initNavigation === 'function') {
        initNavigation = window.initNavigation; // Assign if it exists globally
        initNavigation();
    } else {
        console.warn('initNavigation function not found.');
    }
}

// Initialize includes when the DOM is loaded
document.addEventListener('DOMContentLoaded', initializeIncludes);
/**
 * Include System for SCAD Internship Management System
 * This script handles the inclusion of HTML components like headers, footers, and sidebar navigation
 */

/**
 * Includes HTML content from an external file into a specified element
 * @param {string} elementId - The ID of the element to include content into
 * @param {string} filePath - The path to the HTML file to include
 * @returns {Promise} - A promise that resolves when the content is included
 */
async function includeHTML(elementId, filePath) {
    const element = document.getElementById(elementId);
    if (!element) {
        console.error(`Element with ID "${elementId}" not found.`);
        return;
    }

    try {
        const response = await fetch(filePath);
        if (!response.ok) {
            throw new Error(`Failed to fetch ${filePath}: ${response.status} ${response.statusText}`);
        }

        const html = await response.text();
        element.innerHTML = html;

        // Execute any scripts in the included HTML
        const scripts = element.querySelectorAll('script');
        scripts.forEach(script => {
            const newScript = document.createElement('script');
            if (script.src) {
                newScript.src = script.src;
            } else {
                newScript.textContent = script.textContent;
            }
            document.body.appendChild(newScript);
        });

        return element;
    } catch (error) {
        console.error('Error loading include:', error);
        element.innerHTML = `<div class="error-message">Failed to load content: ${error.message}</div>`;
    }
}

/**
 * Determines the user type based on the current URL path
 * @returns {string} - The user type: 'student', 'company', or 'scad'
 */
function determineUserType() {
    const path = window.location.pathname;
    
    if (path.includes('/student/')) {
        return 'student';
    } else if (path.includes('/company/')) {
        return 'company';
    } else if (path.includes('/scad/')) {
        return 'scad';
    }
    
    // Default to the stored user type or 'student' if none is found
    return localStorage.getItem('userType') || 'student';
}

/**
 * Initializes the include system by loading the appropriate components
 */
async function initializeIncludes() {
    const userType = determineUserType();
    
    // Store the current user type
    localStorage.setItem('userType', userType);
    
    // Include the sidebar navigation
    await includeHTML('sidebar-nav-container', `/includes/${userType}-sidebar-nav.html`);
    
    // Set the page title based on the current page
    setPageTitle();
    
    // Update user info in the header
    updateUserInfo(userType);
    
    // Show/hide PRO features based on user status
    toggleProFeatures();
}

/**
 * Sets the page title based on the current page
 */
function setPageTitle() {
    const pageTitle = document.querySelector('.page-title');
    if (!pageTitle) return;
    
    const path = window.location.pathname;
    let title = 'Dashboard';
    
    if (path.includes('dashboard')) {
        title = 'Dashboard';
    } else if (path.includes('internship-listings')) {
        title = 'Internship Listings';
    } else if (path.includes('student-applications')) {
        title = 'My Applications';
    } else if (path.includes('student-internships')) {
        title = 'My Internships';
    } else if (path.includes('student-reports')) {
        title = 'My Reports';
    } else if (path.includes('student-profile')) {
        title = 'My Profile';
    } else if (path.includes('company-job-posts')) {
        title = 'Job Postings';
    } else if (path.includes('company-applications')) {
        title = 'Applications';
    } else if (path.includes('company-interns')) {
        title = 'Interns';
    } else if (path.includes('company-reports')) {
        title = 'Reports';
    } else if (path.includes('company-profile')) {
        title = 'Company Profile';
    } else if (path.includes('scad-companies')) {
        title = 'Companies';
    } else if (path.includes('scad-internships')) {
        title = 'Internships';
    } else if (path.includes('scad-students')) {
        title = 'Students';
    } else if (path.includes('scad-reports')) {
        title = 'Reports';
    } else if (path.includes('online-assessments')) {
        title = 'Online Assessments';
    } else if (path.includes('workshops')) {
        title = 'Workshops';
    } else if (path.includes('settings')) {
        title = 'Settings';
    }
    
    pageTitle.textContent = title;
}

/**
 * Updates the user info in the header
 * @param {string} userType - The user type: 'student', 'company', or 'scad'
 */
function updateUserInfo(userType) {
    const userNameElement = document.querySelector('.user-name');
    const userRoleElement = document.querySelector('.user-role');
    const userAvatarElement = document.querySelector('.user-avatar');
    const proBadge = document.querySelector('.user-info .badge.pro');
    
    if (!userNameElement || !userRoleElement || !userAvatarElement) return;
    
    // Set user info based on user type
    let userName = 'John Smith';
    let userInitials = 'JS';
    let userRole = 'Student';
    
    if (userType === 'company') {
        userName = 'Acme Inc.';
        userInitials = 'AI';
        userRole = 'Company';
    } else if (userType === 'scad') {
        userName = 'Admin User';
        userInitials = 'AU';
        userRole = 'SCAD Office';
    }
    
    userNameElement.textContent = userName;
    userRoleElement.textContent = userRole;
    userAvatarElement.textContent = userInitials;
    
    // Show/hide PRO badge based on user type and PRO status
    if (proBadge) {
        if (userType === 'student' && isProUser()) {
            proBadge.style.display = 'inline-block';
        } else {
            proBadge.style.display = 'none';
        }
    }
}

/**
 * Check if the current user has PRO status
 * @returns {boolean} - Whether the user has PRO status
 */
function isProUser() {
    // In a real application, this would check the user's status from the server
    // For now, we'll use localStorage for demonstration
    return localStorage.getItem('userProStatus') === 'true';
}

/**
 * Show or hide PRO features based on user status
 */
function toggleProFeatures() {
    const userType = determineUserType();
    
    // Only apply PRO features for student users
    if (userType !== 'student') return;
    
    const isPro = isProUser();
    
    // Show/hide the PRO upgrade banner
    const proUpgradeBanner = document.getElementById('pro-upgrade-banner');
    if (proUpgradeBanner) {
        proUpgradeBanner.style.display = isPro ? 'none' : 'flex';
    }
    
    // Toggle visibility of PRO features
    document.querySelectorAll('.pro-feature').forEach(element => {
        element.style.display = isPro ? 'block' : 'none';
    });
    
    // Show upgrade prompts for non-PRO users
    document.querySelectorAll('.upgrade-prompt').forEach(element => {
        element.style.display = isPro ? 'none' : 'block';
    });
}

// Initialize includes when the DOM is loaded
document.addEventListener('DOMContentLoaded', initializeIncludes);