/**
 * Portal Switcher for SCAD Internship Management System
 * This script handles switching between different portals (Student, Company, SCAD)
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize portal switcher if it exists
    const portalSwitcher = document.querySelector('.portal-switcher');
    if (portalSwitcher) {
        initializePortalSwitcher();
    }
});

/**
 * Initialize the portal switcher
 */
function initializePortalSwitcher() {
    // Get the current user type
    const currentUserType = localStorage.getItem('userType') || 'student';
    
    // Highlight the current portal
    document.querySelectorAll('.portal-option').forEach(option => {
        const portal = option.getAttribute('data-portal');
        if (portal === currentUserType) {
            option.classList.add('active');
        }
        
        // Add click event listener
        option.addEventListener('click', function() {
            switchPortal(portal);
        });
    });
}

/**
 * Switch to a different portal
 * @param {string} portal - The portal to switch to ('student', 'company', or 'scad')
 */
function switchPortal(portal) {
    // Store the new user type
    localStorage.setItem('userType', portal);
    
    // Navigate to the appropriate dashboard
    const dashboards = {
        'student': '/student/student-dashboard.html',
        'company': '/company/company-dashboard.html',
        'scad': '/scad/scad-dashboard.html'
    };
    
    window.location.href = dashboards[portal];
}